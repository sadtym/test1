#!/usr/bin/env python3
"""
سیستم جامع تحلیل و سیگنال‌دهی ارزهای دیجیتال
Crypto Signal Bot - نسخه 1.0.0

این سیستم با ترکیب تحلیل تکنیکال، احساسات بازار و اخبار فاندامنتال،
سیگنال‌های معاملاتی تولید کرده و به تلگرام ارسال می‌کند.

نویسنده: MiniMax Agent
"""

import sys
import os
import logging
import signal
import schedule
import time
from datetime import datetime, timedelta
from typing import Dict, List, Optional
import yaml
import pandas as pd

# اضافه کردن مسیر src به Python path
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from src.data_loader import DataLoader
from src.technical_analysis import TechnicalAnalysis
from src.sentiment_analysis import SentimentAnalyzer
from src.signal_generator import SignalGenerator
from src.telegram_bot import TelegramBot


class CryptoSignalBot:
    """
    کلاس اصلی بات
    هماهنگ‌کننده تمام ماژول‌ها و مدیریت اجرای برنامه
    """
    
    def __init__(self, config_path: str = 'config/config.yaml'):
        """
        مقداردهی اولیه
        
        Args:
            config_path: مسیر فایل پیکربندی
        """
        self.config_path = config_path
        
        # تنظیم لاگینگ اول (ساده برای رفع خطای تعریف نشدن logger)
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        global logger
        logger = logging.getLogger(__name__)
        
        # بارگذاری پیکربندی
        self.config = self._load_config()
        
        # تنظیم لاگینگ کامل
        self._setup_logging()
        
        # مقداردهی اولیه ماژول‌ها
        self._init_modules()
        
        # وضعیت اجرا
        self.running = False
        self.last_market_scan = None
        
        logger.info("="*60)
        logger.info("🚀 سیستم سیگنال‌دهی ارز دیجیتال راه‌اندازی شد")
        logger.info("="*60)
    
    def _load_config(self) -> dict:
        """بارگذاری فایل پیکربندی"""
        try:
            with open(self.config_path, 'r', encoding='utf-8') as f:
                config = yaml.safe_load(f)
            logger.info(f"پیکربندی از {self.config_path} بارگذاری شد")
            return config
        except FileNotFoundError:
            logger.error(f"فایل پیکربندی یافت نشد: {self.config_path}")
            sys.exit(1)
        except Exception as e:
            logger.error(f"خطا در بارگذاری پیکربندی: {str(e)}")
            sys.exit(1)
    
    def _setup_logging(self):
        """تنظیم سیستم لاگینگ"""
        log_config = self.config.get('logging', {})
        log_level = getattr(logging, log_config.get('level', 'INFO'))
        log_format = log_config.get('format', '%(asctime)s - %(name)s - %(levelname)s - %(message)s')
        log_file = log_config.get('file', 'logs/bot.log')
        
        # ایجاد پوشه logs در صورت عدم وجود
        os.makedirs(os.path.dirname(log_file), exist_ok=True)
        
        logging.basicConfig(
            level=log_level,
            format=log_format,
            handlers=[
                logging.FileHandler(log_file, encoding='utf-8'),
                logging.StreamHandler()
            ]
        )
        
        global logger
        logger = logging.getLogger(__name__)
    
    def _init_modules(self):
        """مقداردهی اولیه تمام ماژول‌ها"""
        try:
            # ماژول دریافت داده
            self.data_loader = DataLoader(self.config)
            
            # ماژول تحلیل تکنیکال
            self.technical_analyzer = TechnicalAnalysis(
                self.config.get('technical_analysis', {})
            )
            
            # ماژول تحلیل احساسات
            self.sentiment_analyzer = SentimentAnalyzer(
                self.config.get('sentiment', {})
            )
            
            # ماژول تولید سیگنال
            self.signal_generator = SignalGenerator(self.config)
            
            # ماژول تلگرام
            self.telegram = TelegramBot(self.config.get('telegram', {}))
            
            logger.info("تمام ماژول‌ها مقداردهی اولیه شدند")
            
        except Exception as e:
            logger.error(f"خطا در مقداردهی اولیه ماژول‌ها: {str(e)}")
            raise
    
    def start(self):
        """شروع به کار بات"""
        self.running = True
        
        # تست اتصال تلگرام
        if self.config.get('telegram', {}).get('enabled', False):
            if self.telegram.test_connection():
                # ارسال پیام راه‌اندازی
                config_summary = {
                    'symbols': self.config.get('exchange', {}).get('symbols', []),
                    'timeframe': self.config.get('schedule', {}).get('timeframe', '1h')
                }
                self.telegram.send_startup_notification(config_summary)
            else:
                logger.warning("اتصال تلگرام برقرار نشد - ارسال سیگنال غیرفعال")
        
        # تنظیم زمان‌بندی
        self._setup_schedule()
        
        # اجرای اسکن اولیه
        self.scan_market()
        
        # حلقه اصلی
        self._main_loop()
    
    def stop(self):
        """توقف بات"""
        self.running = False
        logger.info("در حال توقف بات...")
    
    def _setup_schedule(self):
        """تنظیم زمان‌بندی"""
        check_interval = self.config.get('schedule', {}).get('check_interval', 300)
        
        # اسکن منظم بازار
        schedule.every(check_interval).seconds.do(self.scan_market)
        
        # گزارش روزانه
        report_times = self.config.get('schedule', {}).get('daily_report_times', ['08:00', '20:00'])
        for report_time in report_times:
            schedule.every().day.at(report_time).do(self.send_daily_report)
        
        logger.info(f"زمان‌بندی تنظیم شد - اسکن هر {check_interval} ثانیه")
    
    def _main_loop(self):
        """حلقه اصلی اجرا"""
        logger.info("حلقه اصلی شروع شد")
        
        while self.running:
            try:
                schedule.run_pending()
                time.sleep(1)
                
            except KeyboardInterrupt:
                logger.info("دریافت سیگنال Ctrl+C")
                self.stop()
                break
            except Exception as e:
                logger.error(f"خطا در حلقه اصلی: {str(e)}")
                self._handle_error(e)
                time.sleep(10)
    
    def scan_market(self):
        """اسکن کامل بازار"""
        if not self.running:
            return
        
        try:
            logger.info("🔍 شروع اسکن بازار...")
            start_time = datetime.now()
            
            symbols = self.config.get('exchange', {}).get('symbols', [])
            signals = []
            
            # دریافت شاخص ترس و طمع (یکبار برای همه)
            fear_greed_data = self.data_loader.get_fear_greed_data()
            
            # دریافت اخبار (یکبار برای همه)
            all_news = self.data_loader.get_news()
            
            # پردازش هر ارز
            for symbol in symbols:
                try:
                    signal = self._analyze_symbol(
                        symbol, 
                        fear_greed_data, 
                        all_news
                    )
                    if signal:
                        signals.append(signal)
                        
                except Exception as e:
                    logger.error(f"خطا در تحلیل {symbol}: {str(e)}")
                    continue
            
            # ارسال سیگنال‌ها به تلگرام
            if signals:
                self._send_signals(signals)
            
            # آمار اسکن
            elapsed = (datetime.now() - start_time).seconds
            self.last_market_scan = datetime.now()
            
            logger.info(f"✅ اسکن بازار تکمیل شد: {len(signals)} سیگنال در {elapsed} ثانیه")
            
        except Exception as e:
            logger.error(f"خطا در اسکن بازار: {str(e)}")
            self._handle_error(e)
    
    def _analyze_symbol(self, 
                       symbol: str,
                       fear_greed_data: Dict,
                       news_list: List[Dict]) -> Optional:
        """
        تحلیل یک ارز خاص
        
        Args:
            symbol: نماد ارز
            fear_greed_data: داده‌های ترس و طمع
            news_list: لیست اخبار
            
        Returns:
            سیگنال یا None
        """
        # دریافت داده‌های بازار
        market_data = self.data_loader.get_market_data(symbol)
        
        if market_data.empty or len(market_data) < 200:
            logger.warning(f"داده‌های کافی برای {symbol} وجود ندارد")
            return None
        
        # تحلیل تکنیکال
        technical_data = self.technical_analyzer.get_technical_summary(market_data)
        
        # تحلیل احساسات
        symbol_news = [n for n in news_list 
                      if symbol.split('/')[0] in n.get('title', '')]
        
        sentiment_data = self.sentiment_analyzer.get_sentiment_indicator(
            fear_greed_data,
            symbol,
            symbol_news
        )
        
        # اطلاعات قیمت
        current_price = self.data_loader.exchange_loader.get_current_price(symbol)
        price_change = technical_data['indicators'].price_change_24h if 'indicators' in technical_data else 0
        volume = technical_data['indicators'].volume if 'indicators' in technical_data else 0
        
        # تولید سیگنال
        signal = self.signal_generator.generate_signal(
            symbol=symbol,
            technical_data=technical_data,
            sentiment_data=sentiment_data,
            current_price=current_price,
            price_change_24h=price_change,
            volume=volume
        )
        
        return signal
    
    def _send_signals(self, signals: List):
        """ارسال سیگنال‌ها به تلگرام"""
        if not self.config.get('telegram', {}).get('enabled', False):
            return
        
        sent_count = 0
        for signal in signals:
            try:
                if self.telegram.send_signal(signal):
                    sent_count += 1
                    # انتظار کوتاه بین پیام‌ها برای جلوگیری از محدودیت تلگرام
                    time.sleep(0.5)
            except Exception as e:
                logger.error(f"خطا در ارسال سیگنال {signal.symbol}: {str(e)}")
        
        logger.info(f"📤 {sent_count}/{len(signals)} سیگنال به تلگرام ارسال شد")
    
    def send_daily_report(self):
        """ارسال گزارش روزانه"""
        if not self.config.get('telegram', {}).get('enabled', False):
            return
        
        try:
            # آمار سیگنال‌ها
            stats = self.signal_generator.get_statistics()
            
            # احساسات بازار
            fear_greed_data = self.data_loader.get_fear_greed_data()
            sentiment_indicator = self.sentiment_analyzer.get_sentiment_indicator(fear_greed_data)
            
            # ارزهای پرنوسان
            top_movers = self._get_top_movers()
            
            # ارسال گزارش
            self.telegram.send_daily_report(stats, top_movers, sentiment_indicator['combined'])
            
            logger.info("گزارش روزانه ارسال شد")
            
        except Exception as e:
            logger.error(f"خطا در ارسال گزارش روزانه: {str(e)}")
    
    def _get_top_movers(self) -> List[Dict]:
        """دریافت ارزهای پرنوسان"""
        try:
            symbols = self.config.get('exchange', {}).get('symbols', [])
            movers = []
            
            for symbol in symbols:
                market_data = self.data_loader.get_market_data(symbol)
                
                if not market_data.empty:
                    current_price = market_data['close'].iloc[-1]
                    prev_price = market_data['close'].iloc[-2]
                    change = ((current_price - prev_price) / prev_price) * 100
                    
                    movers.append({
                        'symbol': symbol,
                        'price': current_price,
                        'change_percent': change
                    })
            
            # مرتب‌سازی بر اساس قدرت تغییر
            movers.sort(key=lambda x: abs(x['change_percent']), reverse=True)
            
            return movers
            
        except Exception as e:
            logger.error(f"خطا در دریافت ارزهای پرنوسان: {str(e)}")
            return []
    
    def _handle_error(self, error: Exception):
        """مدیریت خطاها"""
        error_type = type(error).__name__
        
        # ارسال هشدار به تلگرام
        if self.config.get('telegram', {}).get('enabled', False):
            self.telegram.send_error_alert(str(error), error_type)
        
        # لاگ کردن
        logger.error(f"خطای {error_type}: {str(error)}")
    
    def get_status(self) -> Dict:
        """دریافت وضعیت بات"""
        return {
            'running': self.running,
            'last_scan': self.last_market_scan.isoformat() if self.last_market_scan else None,
            'signals_today': self.signal_generator.daily_signal_count.get(
                datetime.now().strftime('%Y-%m-%d'), 0
            ),
            'telegram_stats': self.telegram.get_stats()
        }


def signal_handler(signum, frame):
    """مدیریت سیگنال‌های سیستم"""
    logger.info(f"دریافت سیگنال {signum}")
    if 'bot' in globals():
        bot.stop()
    sys.exit(0)


def main():
    """نقطه ورود اصلی برنامه"""
    # ثبت مدیریت سیگنال‌ها
    signal.signal(signal.SIGINT, signal_handler)
    signal.signal(signal.SIGTERM, signal_handler)
    
    # بررسی آرگومان‌های خط فرمان
    config_path = 'config/config.yaml'
    if len(sys.argv) > 1:
        config_path = sys.argv[1]
    
    # ایجاد و شروع بات
    global bot
    try:
        bot = CryptoSignalBot(config_path)
        bot.start()
    except Exception as e:
        logger.error(f"خطای بحرانی: {str(e)}")
        sys.exit(1)


if __name__ == '__main__':
    main()
