"""
ماژول تولید سیگنال
ترکیب تحلیل تکنیکال و فاندامنتال برای تولید سیگنال‌های معاملاتی
نسخه: 1.0.0
"""

import logging
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass, field
from datetime import datetime, timedelta
from enum import Enum
from collections import defaultdict

logger = logging.getLogger(__name__)


class SignalDirection(Enum):
    """جهت سیگنال"""
    BUY = "خرید"
    SELL = "فروش"
    HOLD = "نگهداری"
    STRONG_BUY = "خرید قوی"
    STRONG_SELL = "فروش قوی"


class SignalStrength(Enum):
    """قدرت سیگنال"""
    VERY_WEAK = 1
    WEAK = 2
    MODERATE = 3
    STRONG = 4
    VERY_STRONG = 5


@dataclass
class TradeLevels:
    """سطوح معاملاتی"""
    entry_price: float
    stop_loss: float
    take_profit_1: float
    take_profit_2: float
    take_profit_3: float
    risk_reward_ratio: float
    stop_loss_percentage: float
    take_profit_percentage: float


@dataclass
class Signal:
    """ساختار داده سیگنال"""
    id: str
    symbol: str
    direction: SignalDirection
    strength: SignalStrength
    score: float
    confidence: str
    technical_score: float
    sentiment_score: float
    fear_greed_index: int
    trade_levels: TradeLevels
    reasons: List[str]
    buy_reasons: List[str] = field(default_factory=list)
    sell_reasons: List[str] = field(default_factory=list)
    warnings: List[str] = field(default_factory=list)
    created_at: datetime = field(default_factory=datetime.now)
    valid_until: datetime = None
    current_price: float = 0
    price_change_24h: float = 0
    volume: float = 0
    trend: str = "unknown"
    telegram_message: str = ""
    should_send: bool = True


class SignalGenerator:
    """
    کلاس اصلی تولید سیگنال
    ترکیب تحلیل تکنیکال، احساسات و مدیریت ریسک
    """
    
    def __init__(self, config: dict):
        """
        مقداردهی اولیه
        
        Args:
            config: دیکشنری تنظیمات
        """
        self.config = config
        
        # بارگذاری استراتژی‌ها
        self.strategies = config.get('strategies', {})
        self.buy_strategy = self.strategies.get('buy_strategy', {})
        self.sell_strategy = self.strategies.get('sell_strategy', {})
        self.hold_strategy = self.strategies.get('hold_strategy', {})
        
        # تنظیمات مدیریت ریسک
        self.risk_config = config.get('risk_management', {})
        self.risk_enabled = self.risk_config.get('enabled', True)
        self.max_loss_percent = self.risk_config.get('max_loss_percent', 2)
        self.risk_reward_ratio = self.risk_config.get('risk_reward_ratio', 2)
        self.max_signals_per_day = self.risk_config.get('max_signals_per_day', 10)
        self.cooldown_minutes = self.risk_config.get('cooldown_minutes', 60)
        self.dynamic_stop_loss = self.risk_config.get('dynamic_stop_loss', True)
        
        # تاریخچه سیگنال‌ها
        self.signal_history: List[Signal] = []
        self.last_signal_time: Dict[str, datetime] = {}
        
        # شمارنده سیگنال روزانه
        self.daily_signal_count: Dict[str, int] = defaultdict(int)
        self.last_reset_date: str = datetime.now().strftime('%Y-%m-%d')
        
        logger.info("ماژول تولید سیگنال مقداردهی اولیه شد")
    
    def generate_signal(self,
                       symbol: str,
                       technical_data: Dict,
                       sentiment_data: Dict,
                       current_price: float,
                       price_change_24h: float = 0,
                       volume: float = 0) -> Optional[Signal]:
        """
        تولید سیگنال برای یک ارز
        """
        # بررسی محدودیت‌ها
        if not self._check_limits(symbol):
            logger.debug(f"سیگنال {symbol} به دلیل محدودیت ارسال نشد")
            return None
        
        # استخراج داده‌ها
        indicators = technical_data.get('indicators', {})
        sr_levels = technical_data.get('support_resistance', {})
        trend_data = technical_data.get('trend', {})
        
        fear_greed = sentiment_data.get('fear_greed', {})
        news_sentiment = sentiment_data.get('news', {})
        combined_sentiment = sentiment_data.get('combined', {})
        
        # محاسبه امتیازها
        technical_score = technical_data.get('overall_score', 50)
        sentiment_score = combined_sentiment.get('score', 0)
        
        # بررسی شرایط خرید
        buy_score, buy_reasons = self._evaluate_buy_conditions(
            indicators, sr_levels, fear_greed, combined_sentiment, trend_data
        )
        
        # بررسی شرایط فروش
        sell_score, sell_reasons = self._evaluate_sell_conditions(
            indicators, sr_levels, fear_greed, combined_sentiment, trend_data
        )
        
        # تعیین جهت و امتیاز نهایی
        final_score = buy_score - sell_score
        direction, strength, confidence = self._determine_signal_direction(
            buy_score, sell_score, final_score, technical_score, sentiment_score
        )
        
        # اگر سیگنال HOLD باشد و امتیاز کم باشد، سیگنالی ارسال نکن
        if direction == SignalDirection.HOLD and strength <= SignalStrength.MODERATE:
            return None
        
        # محاسبه سطوح معاملاتی
        trade_levels = self._calculate_trade_levels(
            current_price, direction, sr_levels, indicators
        )
        
        # جمع‌آوری دلایل
        reasons = []
        if buy_reasons:
            reasons.extend([f"✅ {r}" for r in buy_reasons])
        if sell_reasons:
            reasons.extend([f"❌ {r}" for r in sell_reasons])
        
        # هشدارها
        warnings = self._generate_warnings(
            indicators, fear_greed, technical_score, sentiment_score
        )
        
        # ایجاد سیگنال
        signal = Signal(
            id=self._generate_signal_id(symbol),
            symbol=symbol,
            direction=direction,
            strength=strength,
            score=final_score,
            confidence=confidence,
            technical_score=technical_score,
            sentiment_score=sentiment_score,
            fear_greed_index=fear_greed.get('value', 50),
            trade_levels=trade_levels,
            reasons=reasons,
            buy_reasons=buy_reasons,
            sell_reasons=sell_reasons,
            warnings=warnings,
            current_price=current_price,
            price_change_24h=price_change_24h,
            volume=volume,
            trend=trend_data.get('direction', 'unknown'),
            valid_until=datetime.now() + timedelta(hours=4),
            telegram_message=self._format_telegram_message(signal)
        )
        
        # ذخیره در تاریخچه
        self._save_signal(signal)
        
        logger.info(f"سیگنال تولید شد: {symbol} - {direction.value} (امتیاز: {final_score})")
        
        return signal
    
    def _check_limits(self, symbol: str) -> bool:
        """بررسی محدودیت‌های ارسال سیگنال"""
        today = datetime.now().strftime('%Y-%m-%d')
        
        if today != self.last_reset_date:
            self.daily_signal_count.clear()
            self.last_reset_date = today
        
        if self.daily_signal_count.get(today, 0) >= self.max_signals_per_day:
            return False
        
        if symbol in self.last_signal_time:
            time_diff = (datetime.now() - self.last_signal_time[symbol]).minutes
            if time_diff < self.cooldown_minutes:
                return False
        
        return True
    
    def _generate_signal_id(self, symbol: str) -> str:
        """تولید شناسه منحصر به فرد سیگنال"""
        timestamp = datetime.now().strftime('%Y%m%d%H%M%S')
        return f"{symbol.replace('/', '')}_{timestamp}"
    
    def _evaluate_buy_conditions(self,
                                 indicators: Dict,
                                 sr_levels: Dict,
                                 fear_greed: Dict,
                                 sentiment: Dict,
                                 trend: Dict) -> Tuple[int, List[str]]:
        """ارزیابی شرایط خرید"""
        score = 0
        reasons = []
        
        strategy = self.buy_strategy
        conditions = strategy.get('conditions', [])
        
        for condition in conditions:
            cond_type = condition.get('type', '')
            operator = condition.get('operator', '')
            value = condition.get('value', 0)
            weight = condition.get('weight', 1)
            
            is_met = False
            actual_value = 0
            
            if cond_type == 'rsi':
                rsi = indicators.get('rsi', 50)
                actual_value = rsi
                if operator == '<' and rsi < value:
                    is_met = True
                elif operator == '>' and rsi > value:
                    is_met = True
            
            elif cond_type == 'macd_crossover':
                macd_trend = indicators.get('macd_trend', 'neutral')
                direction = condition.get('direction', 'bullish')
                if 'bullish' in macd_trend and direction == 'bullish':
                    is_met = True
                    actual_value = 1
            
            elif cond_type == 'price_above_ema':
                ema_period = condition.get('ema_period', 200)
                price = indicators.get('current_price', 0)
                ema = indicators.get(f'ema_{ema_period}', 0)
                actual_value = price > ema
                if price > ema:
                    is_met = True
            
            elif cond_type == 'fear_greed_index':
                fg_value = fear_greed.get('value', 50)
                actual_value = fg_value
                if operator == '<' and fg_value < value:
                    is_met = True
                elif operator == '>' and fg_value > value:
                    is_met = True
            
            elif cond_type == 'support_level':
                sr_position = sr_levels.get('current_position', '')
                if 'support' in sr_position.lower() or 'bullish' in sr_position.lower():
                    is_met = True
                    actual_value = 1
            
            if is_met:
                score += weight
                reason = self._get_reason_text(cond_type, actual_value, True)
                reasons.append(reason)
        
        return score, reasons
    
    def _evaluate_sell_conditions(self,
                                  indicators: Dict,
                                  sr_levels: Dict,
                                  fear_greed: Dict,
                                  sentiment: Dict,
                                  trend: Dict) -> Tuple[int, List[str]]:
        """ارزیابی شرایط فروش"""
        score = 0
        reasons = []
        
        strategy = self.sell_strategy
        conditions = strategy.get('conditions', [])
        
        for condition in conditions:
            cond_type = condition.get('type', '')
            operator = condition.get('operator', '')
            value = condition.get('value', 0)
            weight = condition.get('weight', 1)
            
            is_met = False
            actual_value = 0
            
            if cond_type == 'rsi':
                rsi = indicators.get('rsi', 50)
                actual_value = rsi
                if operator == '>' and rsi > value:
                    is_met = True
            
            elif cond_type == 'macd_crossover':
                macd_trend = indicators.get('macd_trend', 'neutral')
                direction = condition.get('direction', 'bearish')
                if 'bearish' in macd_trend and direction == 'bearish':
                    is_met = True
                    actual_value = 1
            
            elif cond_type == 'fear_greed_index':
                fg_value = fear_greed.get('value', 50)
                actual_value = fg_value
                if operator == '>' and fg_value > value:
                    is_met = True
            
            elif cond_type == 'resistance_level':
                sr_position = sr_levels.get('current_position', '')
                if 'resistance' in sr_position.lower() or 'bearish' in sr_position.lower():
                    is_met = True
                    actual_value = 1
            
            if is_met:
                score += weight
                reason = self._get_reason_text(cond_type, actual_value, False)
                reasons.append(reason)
        
        return score, reasons
    
    def _get_reason_text(self, cond_type: str, value: Any, is_buy: bool) -> str:
        """تولید متن توضیحی برای شرط"""
        direction = "خرید" if is_buy else "فروش"
        
        reason_map = {
            'rsi': f"RSI در محدوده {'اشباع فروش' if is_buy else 'اشباع خرید'} ({value:.1f})",
            'macd_crossover': f"تقاطع MACD {'صعودی' if is_buy else 'نزولی'}",
            'price_above_ema': f"قیمت بالای EMA 200",
            'price_below_ema': f"قیمت زیر EMA 200",
            'fear_greed_index': f"شاخص ترس و طمع در محدوده {'ترس' if is_buy else 'طمع'} ({value})",
            'support_level': f"قیمت در سطح حمایت",
            'resistance_level': f"قیمت در سطح مقاومت",
            'trend': f"روند {'صعودی' if is_buy else 'نزولی'}",
            'volume': f"افزایش حجم معاملات"
        }
        
        return reason_map.get(cond_type, f"شرط {cond_type} برای {direction}")
    
    def _determine_signal_direction(self,
                                    buy_score: int,
                                    sell_score: int,
                                    final_score: float,
                                    technical_score: float,
                                    sentiment_score: float) -> Tuple[SignalDirection, SignalStrength, str]:
        """تعیین جهت و قدرت سیگنال"""
        score_diff = abs(buy_score - sell_score)
        
        if buy_score > sell_score:
            if buy_score >= 10 and score_diff >= 5:
                direction = SignalDirection.STRONG_BUY
                strength = SignalStrength.VERY_STRONG
                confidence = f"{min(95, 70 + (buy_score * 2))}%"
            elif buy_score >= 7:
                direction = SignalDirection.BUY
                strength = SignalStrength.STRONG
                confidence = f"{min(85, 60 + (buy_score * 3))}%"
            elif buy_score >= 4:
                direction = SignalDirection.BUY
                strength = SignalStrength.MODERATE
                confidence = f"{min(70, 50 + (buy_score * 4))}%"
            else:
                direction = SignalDirection.HOLD
                strength = SignalStrength.WEAK
                confidence = "40%"
        elif sell_score > buy_score:
            if sell_score >= 10 and score_diff >= 5:
                direction = SignalDirection.STRONG_SELL
                strength = SignalStrength.VERY_STRONG
                confidence = f"{min(95, 70 + (sell_score * 2))}%"
            elif sell_score >= 7:
                direction = SignalDirection.SELL
                strength = SignalStrength.STRONG
                confidence = f"{min(85, 60 + (sell_score * 3))}%"
            elif sell_score >= 4:
                direction = SignalDirection.SELL
                strength = SignalStrength.MODERATE
                confidence = f"{min(70, 50 + (sell_score * 4))}%"
            else:
                direction = SignalDirection.HOLD
                strength = SignalStrength.WEAK
                confidence = "40%"
        else:
            direction = SignalDirection.HOLD
            strength = SignalStrength.MODERATE if technical_score > 60 else SignalStrength.WEAK
            confidence = "50%"
        
        return direction, strength, confidence
    
    def _calculate_trade_levels(self,
                                current_price: float,
                                direction: SignalDirection,
                                sr_levels: Dict,
                                indicators: Dict) -> TradeLevels:
        """محاسبه سطوح معاملاتی"""
        if direction in [SignalDirection.BUY, SignalDirection.STRONG_BUY]:
            if self.dynamic_stop_loss:
                bb_lower = indicators.get('bollinger_lower', 0)
                atr = (indicators.get('bollinger_upper', current_price) - 
                       indicators.get('bollinger_lower', current_price)) / 2
                
                if bb_lower > 0 and current_price - bb_lower < atr * 2:
                    stop_loss = bb_lower * 0.99
                else:
                    stop_loss = current_price * (1 - self.max_loss_percent / 100)
            else:
                stop_loss = current_price * (1 - self.max_loss_percent / 100)
            
            risk = current_price - stop_loss
            rr = self.risk_reward_ratio
            
            take_profit_1 = current_price + risk * rr
            take_profit_2 = current_price + risk * (rr * 1.5)
            take_profit_3 = current_price + risk * (rr * 2)
            
        elif direction in [SignalDirection.SELL, SignalDirection.STRONG_SELL]:
            if self.dynamic_stop_loss:
                bb_upper = indicators.get('bollinger_upper', 0)
                atr = (indicators.get('bollinger_upper', current_price) - 
                       indicators.get('bollinger_lower', current_price)) / 2
                
                if bb_upper > 0 and bb_upper - current_price < atr * 2:
                    stop_loss = bb_upper * 1.01
                else:
                    stop_loss = current_price * (1 + self.max_loss_percent / 100)
            else:
                stop_loss = current_price * (1 + self.max_loss_percent / 100)
            
            risk = stop_loss - current_price
            rr = self.risk_reward_ratio
            
            take_profit_1 = current_price - risk * rr
            take_profit_2 = current_price - risk * (rr * 1.5)
            take_profit_3 = current_price - risk * (rr * 2)
        
        else:
            stop_loss = current_price * 0.95
            take_profit_1 = current_price * 1.05
            take_profit_2 = current_price * 1.10
            take_profit_3 = current_price * 1.15
            risk = abs(current_price - stop_loss)
        
        stop_loss_pct = abs((current_price - stop_loss) / current_price) * 100
        take_profit_pct = abs((take_profit_1 - current_price) / current_price) * 100
        
        return TradeLevels(
            entry_price=current_price,
            stop_loss=stop_loss,
            take_profit_1=take_profit_1,
            take_profit_2=take_profit_2,
            take_profit_3=take_profit_3,
            risk_reward_ratio=self.risk_reward_ratio,
            stop_loss_percentage=stop_loss_pct,
            take_profit_percentage=take_profit_pct
        )
    
    def _generate_warnings(self,
                          indicators: Dict,
                          fear_greed: Dict,
                          technical_score: float,
                          sentiment_score: float) -> List[str]:
        """تولید هشدارها"""
        warnings = []
        
        rsi = indicators.get('rsi', 50)
        if rsi >= 75:
            warnings.append("⚠️ RSI در منطقه اشباع خرید شدید")
        elif rsi <= 25:
            warnings.append("⚠️ RSI در منطقه اشباع فروش شدید")
        
        volume_ratio = indicators.get('volume_ratio', 1)
        if volume_ratio > 3:
            warnings.append("⚠️ حجم معاملات بسیار بالا - احتیاط")
        elif volume_ratio < 0.3:
            warnings.append("⚠️ حجم معاملات پایین - کاهش نقدشوندگی")
        
        fg_value = fear_greed.get('value', 50)
        if fg_value <= 20:
            warnings.append("⚠️ ترس شدید در بازار - فرصت خرید اما ریسک بالا")
        elif fg_value >= 80:
            warnings.append("⚠️ طمع شدید در بازار - احتمال اصلاح")
        
        trend = indicators.get('macd_trend', 'neutral')
        if 'weakening' in trend:
            warnings.append("⚠️ قدرت روند در حال کاهش")
        
        return warnings
    
    def _format_telegram_message(self, signal: Signal) -> str:
        """فرمت‌بندی پیام تلگرام"""
        emoji_map = {
            SignalDirection.BUY: "🟢",
            SignalDirection.STRONG_BUY: "🟢🌟",
            SignalDirection.SELL: "🔴",
            SignalDirection.STRONG_SELL: "🔴🌟",
            SignalDirection.HOLD: "🟡"
        }
        
        emoji = emoji_map.get(signal.direction, "⚪")
        
        if signal.current_price >= 100:
            price_format = f"${signal.current_price:,.2f}"
        elif signal.current_price >= 1:
            price_format = f"${signal.current_price:,.4f}"
        else:
            price_format = f"${signal.current_price:,.6f}"
        
        message = f"""
{emoji} <b>سیگنال {signal.direction.value}</b> - {signal.symbol}

📊 <b>خلاصه تحلیل:</b>
• جهت: {signal.direction.value}
• قدرت: {signal.strength.name}
• اطمینان: {signal.confidence}
• امتیاز کلی: {signal.score:.1f}/100

💰 <b>سطوح معاملاتی:</b>
• قیمت ورود: {price_format}
• حد ضرر (SL): ${signal.trade_levels.stop_loss:,.6f} ({signal.trade_levels.stop_loss_percentage:.2f}%)
• هدف اول (TP1): ${signal.trade_levels.take_profit_1:,.6f} ({signal.trade_levels.take_profit_percentage:.2f}%)
• هدف دوم (TP2): ${signal.trade_levels.take_profit_2:,.6f}
• هدف سوم (TP3): ${signal.trade_levels.take_profit_3:,.6f}
• نسبت ریسک به سود: 1:{signal.trade_levels.risk_reward_ratio}

📈 <b>شاخص‌های کلیدی:</b>
• RSI: {signal.technical_score:.1f}
• شاخص ترس و طمع: {signal.fear_greed_index}
• روند: {signal.trend}

🔍 <b>دلایل:</b>
{chr(10).join(signal.reasons[:5]) if signal.reasons else 'اطلاعاتی موجود نیست'}

{'⚠️ هشدارها:' + chr(10) + chr(10).join(signal.warnings) if signal.warnings else ''}

⏰ زمان ایجاد: {signal.created_at.strftime('%Y-%m-%d %H:%M:%S')}
📅 معتبر تا: {signal.valid_until.strftime('%Y-%m-%d %H:%M:%S')}

<i>⚠️ این تحلیل صرفاً جنبه اطلاع‌رسانی دارد و توصیه سرمایه‌گذاری نیست.</i>
"""
        return message
    
    def _save_signal(self, signal: Signal):
        """ذخیره سیگنال در تاریخچه"""
        self.signal_history.append(signal)
        self.last_signal_time[signal.symbol] = datetime.now()
        
        today = datetime.now().strftime('%Y-%m-%d')
        self.daily_signal_count[today] += 1
        
        if len(self.signal_history) > 1000:
            self.signal_history = self.signal_history[-500:]
    
    def get_signal_history(self, symbol: str = None, days: int = 7) -> List[Signal]:
        """دریافت تاریخچه سیگنال‌ها"""
        cutoff = datetime.now() - timedelta(days=days)
        
        if symbol:
            return [s for s in self.signal_history 
                   if s.symbol == symbol and s.created_at > cutoff]
        
        return [s for s in self.signal_history if s.created_at > cutoff]
    
    def get_statistics(self) -> Dict:
        """دریافت آمار سیگنال‌ها"""
        if not self.signal_history:
            return {
                'total_signals': 0,
                'buy_signals': 0,
                'sell_signals': 0,
                'hold_signals': 0,
                'avg_score': 0
            }
        
        buy_count = sum(1 for s in self.signal_history 
                       if s.direction in [SignalDirection.BUY, SignalDirection.STRONG_BUY])
        sell_count = sum(1 for s in self.signal_history 
                        if s.direction in [SignalDirection.SELL, SignalDirection.STRONG_SELL])
        
        return {
            'total_signals': len(self.signal_history),
            'buy_signals': buy_count,
            'sell_signals': sell_count,
            'hold_signals': len(self.signal_history) - buy_count - sell_count,
            'avg_score': sum(s.score for s in self.signal_history) / len(self.signal_history)
        }
