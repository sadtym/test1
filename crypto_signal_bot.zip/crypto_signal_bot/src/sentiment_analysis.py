"""
ماژول تحلیل احساسات و فاندامنتال
شامل: شاخص ترس و طمع، تحلیل اخبار، احساسات شبکه‌های اجتماعی
نسخه: 1.0.0
"""

import pandas as pd
import re
import logging
from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import Enum

logger = logging.getLogger(__name__)


class SentimentCategory(Enum):
    """دسته‌بندی احساسات"""
    VERY_BEARISH = "بسیار نزولی"
    BEARISH = "نزولی"
    SLIGHTLY_BEARISH = "کمی نزولی"
    NEUTRAL = "خنثی"
    SLIGHTLY_BULLISH = "کمی صعودی"
    BULLISH = "صعودی"
    VERY_BULLISH = "بسیار صعودی"


class FearGreedClassification(Enum):
    """دسته‌بندی شاخص ترس و طمع"""
    EXTREME_FEAR = "ترس شدید"
    FEAR = "ترس"
    NEUTRAL = "خنثی"
    GREED = "طمع"
    EXTREME_GREED = "طمع شدید"


@dataclass
class NewsSentiment:
    """ساختار داده احساسات اخبار"""
    news_title: str
    news_url: str
    sentiment_score: float  # -1 تا 1
    sentiment_category: SentimentCategory
    source: str
    published_at: str
    related_currencies: List[str]
    importance: str  # high, medium, low


@dataclass
class OverallSentiment:
    """ساختار داده احساسات کلی"""
    fear_greed_index: int
    fear_greed_classification: str
    fear_greed_emoji: str
    news_sentiment_score: float
    news_sentiment_category: SentimentCategory
    social_sentiment_score: float
    combined_score: float  # ترکیب تمام احساسات
    sentiment_summary: str
    is_positive: bool
    is_extreme: bool  # آیا در حالت افراطی است


class SentimentAnalyzer:
    """
    کلاس اصلی تحلیل احساسات
    تحلیل شاخص ترس و طمع، اخبار و احساسات شبکه‌های اجتماعی
    """
    
    def __init__(self, config: dict):
        """
        مقداردهی اولیه
        
        Args:
            config: دیکشنری تنظیمات تحلیل احساسات
        """
        self.config = config
        self.enabled = config.get('enabled', True)
        
        # تنظیمات ترس و طمع
        self.fear_greed_config = config.get('fear_greed', {})
        self.fear_greed_enabled = self.fear_greed_config.get('enabled', True)
        self.thresholds = {
            'extreme_fear': self.fear_greed_config.get('threshold_extreme_fear', 25),
            'fear': self.fear_greed_config.get('threshold_fear', 40),
            'greed': self.fear_greed_config.get('threshold_greed', 60),
            'extreme_greed': self.fear_greed_config.get('threshold_extreme_greed', 75)
        }
        
        # تنظیمات اخبار
        self.news_config = config.get('news', {})
        self.news_enabled = self.news_config.get('enabled', True)
        self.news_sensitivity = self.news_config.get('sensitivity', 5)
        
        # تنظیمات احساسات اجتماعی
        self.social_config = config.get('social_sentiment', {})
        self.social_enabled = self.social_config.get('enabled', False)
        
        # دیکشنری کلمات کلیدی احساسات
        self._init_sentiment_words()
        
        logger.info("ماژول تحلیل احساسات مقداردهی اولیه شد")
    
    def _init_sentiment_words(self):
        """مقداردهی اولیه کلمات کلیدی احساسات"""
        # کلمات صعودی (وزن مثبت)
        self.bullish_words = {
            'high': 2, 'moon': 3, 'pump': 2, 'surge': 2, 'rally': 2,
            'breakout': 3, 'bullish': 3, 'gain': 2, 'profit': 2,
            'adoption': 2, 'partnership': 2, 'upgrade': 2, 'launch': 2,
            'innovation': 2, 'partners': 2, 'growth': 2, 'success': 2,
            'win': 2, 'record': 2, 'milestone': 3, 'integration': 2,
            'listing': 2, 'support': 1, 'rallying': 2, 'soaring': 2,
            'jumps': 2, 'rising': 2, 'climbs': 2, 'surges': 2,
            'bullrun': 3, 'all-time': 3, ' ATH ': 3, 'hodl': 1,
            'green': 1, 'buy': 2, 'accumulate': 2, 'long': 1
        }
        
        # کلمات نزولی (وزن منفی)
        self.bearish_words = {
            'crash': -3, 'dump': -2, 'sell': -2, 'loss': -2,
            'bearish': -3, 'drop': -2, 'plunge': -3, 'tumble': -3,
            'hack': -2, 'scam': -3, 'ban': -3, 'crackdown': -3,
            'regulation': -1, 'lawsuit': -2, 'investigation': -2,
            'concern': -1, 'warning': -1, 'risk': -1, 'threat': -2,
            'fear': -1, 'uncertainty': -1, 'panic': -2, 'worried': -2,
            'decline': -2, 'falls': -2, 'slumps': -2, 'dips': -1,
            'red': -1, 'sell-off': -2, 'correction': -1, 'bear market': -2,
            'death cross': -3, 'rejection': -2, 'resistance': -1,
            'profit-taking': -2, 'overbought': -1, 'bubble': -2
        }
        
        # کلمات خنثی یا اطلاعاتی
        self.neutral_words = {
            'stable': 0, 'stablecoin': 0, 'hold': 0, 'waiting': 0,
            'range': 0, 'consolidation': 0, 'sideways': 0, 'flat': 0
        }
    
    def analyze_fear_greed(self, fear_greed_data: Dict) -> Dict:
        """
        تحلیل شاخص ترس و طمع
        
        Args:
            fear_greed_data: داده‌های شاخص ترس و طمع
            
        Returns:
            دیکشنری تحلیل شاخص
        """
        value = fear_greed_data.get('value', 50)
        classification = fear_greed_data.get('classification', 'Neutral')
        emoji = fear_greed_data.get('emoji', '😐')
        
        # تعیین وضعیت بازار بر اساس شاخص
        if value <= self.thresholds['extreme_fear']:
            market_sentiment = FearGreedClassification.EXTREME_FEAR
            opportunity = "فرصت خرید عالی - وحشت در بازار"
            risk_level = "بالا (فرصت)"
        elif value <= self.thresholds['fear']:
            market_sentiment = FearGreedClassification.FEAR
            opportunity = "فرصت خرید خوب - ترس در بازار"
            risk_level = "متوسط"
        elif value <= self.thresholds['greed']:
            market_sentiment = FearGreedClassification.NEUTRAL
            opportunity = "بی‌طرفی - منتظر سیگنال باشید"
            risk_level = "متوسط"
        elif value <= self.thresholds['extreme_greed']:
            market_sentiment = FearGreedClassification.GREED
            opportunity = "احتیاط - طمع در بازار"
            risk_level = "بالا (ریسک)"
        else:
            market_sentiment = FearGreedClassification.EXTREME_GREED
            opportunity = "هشدار ریسک بالا - حباب احتمالی"
            risk_level = "بسیار بالا"
        
        # تبدیل به امتیاز (-100 تا 100)
        sentiment_score = (value - 50) * 2  # 0-100 -> -100 تا 100
        
        return {
            'value': value,
            'classification': classification,
            'emoji': emoji,
            'market_sentiment': market_sentiment.value,
            'opportunity': opportunity,
            'risk_level': risk_level,
            'sentiment_score': sentiment_score,
            'is_extreme': value <= self.thresholds['extreme_fear'] or value >= self.thresholds['extreme_greed'],
            'is_fear': value < 50,
            'is_greed': value > 50
        }
    
    def analyze_news(self, news_list: List[Dict]) -> Tuple[List[NewsSentiment], Dict]:
        """
        تحلیل احساسات اخبار
        
        Args:
            news_list: لیست اخبار
            
        Returns:
            Tuple(لیست احساسات خبر, خلاصه تحلیل)
        """
        analyzed_news = []
        total_score = 0
        positive_count = 0
        negative_count = 0
        neutral_count = 0
        high_importance_count = 0
        
        for news in news_list:
            title = news.get('title', '')
            url = news.get('url', '')
            source = news.get('source', 'Unknown')
            published_at = news.get('published_at', '')
            currencies = news.get('currencies', [])
            
            # تحلیل احساسات عنوان خبر
            sentiment_score = self._analyze_text_sentiment(title)
            
            # تعیین دسته‌بندی احساسات
            if sentiment_score >= 0.6:
                category = SentimentCategory.VERY_BULLISH
            elif sentiment_score >= 0.3:
                category = SentimentCategory.BULLISH
            elif sentiment_score >= 0.1:
                category = SentimentCategory.SLIGHTLY_BULLISH
            elif sentiment_score <= -0.6:
                category = SentimentCategory.VERY_BEARISH
            elif sentiment_score <= -0.3:
                category = SentimentCategory.BEARISH
            elif sentiment_score <= -0.1:
                category = SentimentCategory.SLIGHTLY_BEARISH
            else:
                category = SentimentCategory.NEUTRAL
            
            # تعیین اهمیت خبر
            importance = self._assess_news_importance(title, source)
            
            # آمار
            total_score += sentiment_score
            if sentiment_score > 0.1:
                positive_count += 1
            elif sentiment_score < -0.1:
                negative_count += 1
            else:
                neutral_count += 1
            
            if importance == 'high':
                high_importance_count += 1
            
            analyzed_news.append(NewsSentiment(
                news_title=title,
                news_url=url,
                sentiment_score=sentiment_score,
                sentiment_category=category,
                source=source,
                published_at=published_at,
                related_currencies=currencies,
                importance=importance
            ))
        
        # محاسبه میانگین احساسات
        avg_score = total_score / len(news_list) if news_list else 0
        
        # تعیین دسته‌بندی کلی
        if avg_score >= 0.5:
            overall_category = SentimentCategory.VERY_BULLISH
        elif avg_score >= 0.2:
            overall_category = SentimentCategory.BULLISH
        elif avg_score >= 0.1:
            overall_category = SentimentCategory.SLIGHTLY_BULLISH
        elif avg_score <= -0.5:
            overall_category = SentimentCategory.VERY_BEARISH
        elif avg_score <= -0.2:
            overall_category = SentimentCategory.BEARISH
        elif avg_score <= -0.1:
            overall_category = SentimentCategory.SLIGHTLY_BEARISH
        else:
            overall_category = SentimentCategory.NEUTRAL
        
        summary = {
            'total_news': len(news_list),
            'positive_news': positive_count,
            'negative_news': negative_count,
            'neutral_news': neutral_count,
            'high_importance_news': high_importance_count,
            'average_sentiment_score': avg_score,
            'overall_category': overall_category.value,
            'sentiment_ratio': positive_count / max(1, (positive_count + negative_count))
        }
        
        return analyzed_news, summary
    
    def _analyze_text_sentiment(self, text: str) -> float:
        """
        تحلیل احساسات یک متن
        
        Args:
            text: متن مورد نظر
            
        Returns:
            امتیاز احساسات (-1 تا 1)
        """
        if not text:
            return 0.0
        
        text_lower = text.lower()
        words = re.findall(r'\b\w+\b', text_lower)
        
        total_score = 0
        word_count = 0
        
        for word in words:
            if word in self.bullish_words:
                total_score += self.bullish_words[word]
                word_count += 1
            elif word in self.bearish_words:
                total_score += self.bearish_words[word]
                word_count += 1
            elif word in self.neutral_words:
                word_count += 1
        
        if word_count == 0:
            return 0.0
        
        # نرمال‌سازی امتیاز به محدوده -1 تا 1
        normalized_score = total_score / (word_count * 3)  # حداکثر وزن 3
        
        return max(-1.0, min(1.0, normalized_score))
    
    def _assess_news_importance(self, title: str, source: str) -> str:
        """
        تعیین اهمیت یک خبر
        
        Args:
            title: عنوان خبر
            source: منبع خبر
            
        Returns:
            سطح اهمیت (high, medium, low)
        """
        high_importance_keywords = [
            'ban', 'banned', 'hack', 'hacked', 'exploit', 'security breach',
            'regulation', 'sec', 'cftc', 'doj', 'investigation', 'lawsuit',
            'partnership', 'major', 'announcement', 'breaking', 'update',
            'launch', 'listing', 'delisting', 'suspend', 'blacklist'
        ]
        
        medium_importance_keywords = [
            'report', 'analysis', 'opinion', 'interview', 'prediction',
            'forecast', 'survey', 'study', 'data', 'statistics', 'adoption'
        ]
        
        # منابع معتبر
        reliable_sources = ['coindesk', 'cointelegraph', 'reuters', 'bloomberg', 
                           'financial times', 'wall street journal']
        
        title_lower = title.lower()
        
        # بررسی کلمات کلیدی اهمیت بالا
        for keyword in high_importance_keywords:
            if keyword in title_lower:
                return 'high'
        
        # بررسی منابع معتبر
        for source_name in reliable_sources:
            if source_name in source.lower():
                return 'high'
        
        # بررسی کلمات کلیدی اهمیت متوسط
        for keyword in medium_importance_keywords:
            if keyword in title_lower:
                return 'medium'
        
        return 'low'
    
    def analyze_social_sentiment(self, symbol: str, social_data: Dict) -> Dict:
        """
        تحلیل احساسات شبکه‌های اجتماعی
        
        Args:
            symbol: نماد ارز
            social_data: داده‌های شبکه‌های اجتماعی
            
        Returns:
            دیکشنری تحلیل احساسات اجتماعی
        """
        # این بخش نیاز به API خارجی دارد
        # پیاده‌سازی پایه
        
        if not self.social_enabled:
            return {
                'enabled': False,
                'message': 'تحلیل احساسات اجتماعی غیرفعال است',
                'score': 0,
                'classification': 'Unknown'
            }
        
        # TODO: اتصال به APIهایی مانند LunarCrush, Santiment, CryptoQuant
        return {
            'enabled': True,
            'score': 0,
            'mention_volume': 0,
            'sentiment_ratio': 0.5,
            'dominant_sentiment': 'Neutral',
            'source': 'N/A'
        }
    
    def get_combined_sentiment(self, 
                               fear_greed_data: Dict,
                               news_list: List[Dict],
                               social_data: Dict = None) -> OverallSentiment:
        """
        ترکیب تمام منابع احساسات
        
        Args:
            fear_greed_data: داده‌های ترس و طمع
            news_list: لیست اخبار
            social_data: داده‌های شبکه‌های اجتماعی
            
        Returns:
            OverallSentiment: احساسات کلی ترکیب شده
        """
        # تحلیل ترس و طمع
        fg_analysis = self.analyze_fear_greed(fear_greed_data)
        fg_score = fg_analysis['sentiment_score']  # -100 تا 100
        
        # تحلیل اخبار
        analyzed_news, news_summary = self.analyze_news(news_list)
        news_score = news_summary['average_sentiment_score'] * 100  # تبدیل به -100 تا 100
        
        # تحلیل احساسات اجتماعی
        social_analysis = self.analyze_social_sentiment('', social_data or {})
        social_score = social_analysis.get('score', 0)
        
        # وزن‌دهی به منابع مختلف
        weights = {
            'fear_greed': 0.4,  # 40% وزن
            'news': 0.4,        # 40% وزن
            'social': 0.2       # 20% وزن
        }
        
        # محاسبه امتیاز ترکیبی
        combined_score = (
            weights['fear_greed'] * fg_score +
            weights['news'] * news_score +
            weights['social'] * social_score
        )
        
        # تعیین خلاصه احساسات
        if combined_score >= 50:
            sentiment_summary = "احساسات بسیار صعودی - احتمال رشد قیمت"
        elif combined_score >= 20:
            sentiment_summary = "احساسات صعودی - روند مثبت"
        elif combined_score >= 5:
            sentiment_summary = "احساسات کمی صعودی - انتظار برای تایید"
        elif combined_score >= -5:
            sentiment_summary = "احساسات خنثی - بی‌تصمیمی در بازار"
        elif combined_score >= -20:
            sentiment_summary = "احساسات کمی نزولی - احتیاط توصیه می‌شود"
        elif combined_score >= -50:
            sentiment_summary = "احساسات نزولی - فشار فروش"
        else:
            sentiment_summary = "احساسات بسیار نزولی - ریسک بالا"
        
        return OverallSentiment(
            fear_greed_index=fear_greed_data.get('value', 50),
            fear_greed_classification=fg_analysis['classification'],
            fear_greed_emoji=fg_analysis['emoji'],
            news_sentiment_score=news_score,
            news_sentiment_category=news_summary['overall_category'],
            social_sentiment_score=social_score,
            combined_score=combined_score,
            sentiment_summary=sentiment_summary,
            is_positive=combined_score > 10,
            is_extreme=fg_analysis['is_extreme'] or abs(combined_score) > 60
        )
    
    def get_sentiment_indicator(self, 
                                fear_greed_data: Dict,
                                symbol: str = None,
                                news_list: List[Dict] = None) -> Dict:
        """
        دریافت شاخص احساسات برای نمایش
        
        Args:
            fear_greed_data: داده‌های ترس و طمع
            symbol: نماد ارز (اختیاری)
            news_list: لیست اخبار (اختیاری)
            
        Returns:
            دیکشنری شاخص احساسات
        """
        # فیلتر اخبار برای ارز خاص
        if symbol and news_list:
            base_currency = symbol.split('/')[0]
            filtered_news = [
                n for n in news_list 
                if base_currency in n.get('currencies', []) or 
                   base_currency in n.get('title', '')
            ]
        else:
            filtered_news = news_list or []
        
        # دریافت احساسات کلی
        combined = self.get_combined_sentiment(
            fear_greed_data,
            filtered_news
        )
        
        return {
            'fear_greed': {
                'value': combined.fear_greed_index,
                'classification': combined.fear_greed_classification,
                'emoji': combined.fear_greed_emoji
            },
            'news': {
                'score': combined.news_sentiment_score,
                'category': combined.news_sentiment_category.value
            },
            'combined': {
                'score': combined.combined_score,
                'summary': combined.sentiment_summary,
                'is_positive': combined.is_positive,
                'is_extreme': combined.is_extreme
            },
            'timestamp': datetime.now().isoformat()
        }
    
    def get_market_sentiment_signal(self, fear_greed_data: Dict) -> Tuple[str, str, int]:
        """
        دریافت سیگنال احساسات بازار
        
        Args:
            fear_greed_data: داده‌های ترس و طمع
            
        Returns:
            Tuple(سیگنال, توضیح, قدرت سیگنال)
        """
        value = fear_greed_data.get('value', 50)
        
        if value <= 20:
            return (
                "🟢 BUY SIGNAL - EXTREME FEAR",
                "ترس شدید در بازار - فرصت خرید عالی",
                3  # قدرت سیگنال (1-3)
            )
        elif value <= 35:
            return (
                "🟢 BUY SIGNAL - FEAR",
                "ترس در بازار - فرصت خرید خوب",
                2
            )
        elif value <= 45:
            return (
                "🟡 NEUTRAL - SLIGHT FEAR",
                "ترس خفیف - احتیاط در خرید",
                1
            )
        elif value <= 55:
            return (
                "⚪ NEUTRAL",
                "بازار خنثی - منتظر سیگنال باشید",
                0
            )
        elif value <= 65:
            return (
                "🟡 NEUTRAL - SLIGHT GREED",
                "طمع خفیف - نظارت بر سود",
                1
            )
        elif value <= 80:
            return (
                "🔴 SELL SIGNAL - GREED",
                "طمع در بازار - احتمال اصلاح",
                2
            )
        else:
            return (
                "🔴 SELL SIGNAL - EXTREME GREED",
                "طمع شدید - ریسک بالا",
                3
            )
