"""
ماژول دریافت داده‌های بازار، اخبار و شاخص ترس و طمع
نسخه: 1.0.0
"""

import ccxt
import pandas as pd
import requests
import logging
from datetime import datetime, timedelta
from typing import Dict, List, Optional, Tuple
from abc import ABC, abstractmethod

logger = logging.getLogger(__name__)


class BaseDataLoader(ABC):
    """کلاس پایه برای دریافت‌کننده‌های داده"""
    
    @abstractmethod
    def fetch_data(self, symbol: str, timeframe: str, limit: int) -> pd.DataFrame:
        """دریافت داده‌ها"""
        pass
    
    @abstractmethod
    def get_current_price(self, symbol: str) -> float:
        """دریافت قیمت فعلی"""
        pass


class ExchangeDataLoader(BaseDataLoader):
    """
    کلاس دریافت داده از صرافی‌ها
    پشتیبانی از: Binance, KuCoin, Coinbase, و بیش از 100 صرافی دیگر
    """
    
    def __init__(self, config: dict):
        """
        مقداردهی اولیه
        
        Args:
            config: دیکشنری تنظیمات شامل نام صرافی و اطلاعات احراز هویت
        """
        self.config = config
        self.exchange_name = config.get('name', 'binance')
        self.api_key = config.get('api_key', '')
        self.api_secret = config.get('api_secret', '')
        self.testnet = config.get('testnet', False)
        
        # مقداردهی اولیه صرافی
        self.exchange = self._init_exchange()
        
        # پاکسازی نام جفت‌ارزها
        self.symbols = [s.replace('/', '') for s in config.get('symbols', [])]
        
        logger.info(f"دریافت‌کننده داده صرافی {self.exchange_name} مقداردهی اولیه شد")
    
    def _init_exchange(self) -> ccxt.Exchange:
        """مقداردهی اولیه اتصال به صرافی"""
        try:
            if self.api_key and self.api_secret:
                # اتصال با احراز هویت
                exchange_class = getattr(ccxt, self.exchange_name)
                exchange = exchange_class({
                    'apiKey': self.api_key,
                    'secret': self.api_secret,
                    'enableRateLimit': True,
                    'options': {
                        'defaultType': 'spot',
                    }
                })
            else:
                # اتصال بدون احراز هویت (داده‌های عمومی)
                exchange_class = getattr(ccxt, self.exchange_name)
                exchange = exchange_class({
                    'enableRateLimit': True,
                })
            
            # تنظیم تست‌نت برای بایننس
            if self.testnet and self.exchange_name == 'binance':
                exchange.set_sandbox_mode(True)
                
            return exchange
            
        except AttributeError:
            logger.error(f"صرافی {self.exchange_name} پشتیبانی نمی‌شود")
            raise ValueError(f"صرافی پشتیبانی نشده: {self.exchange_name}")
        except Exception as e:
            logger.error(f"خطا در اتصال به صرافی: {str(e)}")
            raise
    
    def fetch_ohlcv(self, symbol: str, timeframe: str = '1h', limit: int = 100) -> pd.DataFrame:
        """
        دریافت داده‌های OHLCV (قیمت باز، بالا، پایین، بسته، حجم)
        
        Args:
            symbol: نماد ارز (مثلاً BTC/USDT)
            timeframe: بازه زمانی کندل‌ها
            limit: تعداد کندل‌های درخواستی
            
        Returns:
            DataFrame حاوی داده‌های کندل‌ها
        """
        try:
            # تبدیل فرمت نماد
            clean_symbol = symbol.replace('/', '')
            
            # دریافت داده‌ها از صرافی
            ohlcv = self.exchange.fetch_ohlcv(
                symbol=symbol,
                timeframe=timeframe,
                limit=limit
            )
            
            # تبدیل به DataFrame
            df = pd.DataFrame(ohlcv, columns=[
                'timestamp', 'open', 'high', 'low', 'close', 'volume'
            ])
            
            # تبدیل timestamp به datetime
            df['datetime'] = pd.to_datetime(df['timestamp'], unit='ms')
            df.set_index('datetime', inplace=True)
            
            # محاسبه تغییرات قیمت
            df['price_change'] = df['close'].pct_change()
            df['price_change_pct'] = df['close'].pct_change() * 100
            
            # محاسبه حجم معاملات به دلار (تخمینی)
            df['volume_usd'] = df['volume'] * df['close']
            
            logger.debug(f"داده‌های OHLCV برای {symbol} دریافت شد: {len(df)} کندل")
            
            return df
            
        except ccxt.NetworkError as e:
            logger.error(f"خطای شبکه در دریافت داده‌های {symbol}: {str(e)}")
            return pd.DataFrame()
        except ccxt.ExchangeError as e:
            logger.error(f"خطای صرافی در دریافت داده‌های {symbol}: {str(e)}")
            return pd.DataFrame()
        except Exception as e:
            logger.error(f"خطای ناشناخته در دریافت داده‌های {symbol}: {str(e)}")
            return pd.DataFrame()
    
    def fetch_data(self, symbol: str, timeframe: str, limit: int) -> pd.DataFrame:
        """پیاده‌سازی متد انتزاعی"""
        return self.fetch_ohlcv(symbol, timeframe, limit)
    
    def get_current_price(self, symbol: str) -> float:
        """
        دریافت قیمت فعلی یک ارز
        
        Args:
            symbol: نماد ارز (مثلاً BTC/USDT)
            
        Returns:
            قیمت فعلی
        """
        try:
            ticker = self.exchange.fetch_ticker(symbol)
            return ticker['last']
            
        except Exception as e:
            logger.error(f"خطا در دریافت قیمت {symbol}: {str(e)}")
            return 0.0
    
    def get_order_book(self, symbol: str, limit: int = 20) -> Dict:
        """
        دریافت دفتر سفارشات
        
        Args:
            symbol: نماد ارز
            limit: تعداد سطوح قیمت
            
        Returns:
            دیکشنری شامل bids و asks
        """
        try:
            order_book = self.exchange.fetch_order_book(symbol, limit)
            return {
                'bids': order_book['bids'],
                'asks': order_book['asks'],
                'bid_volume': sum(b[1] for b in order_book['bids']),
                'ask_volume': sum(a[1] for a in order_book['asks'])
            }
        except Exception as e:
            logger.error(f"خطا در دریافت دفتر سفارشات {symbol}: {str(e)}")
            return {'bids': [], 'asks': [], 'bid_volume': 0, 'ask_volume': 0}
    
    def get_recent_trades(self, symbol: str, limit: int = 50) -> List[Dict]:
        """
        دریافت معاملات اخیر
        
        Args:
            symbol: نماد ارز
            limit: تعداد معاملات
            
        Returns:
            لیست معاملات اخیر
        """
        try:
            trades = self.exchange.fetch_trades(symbol, limit=limit)
            return [{
                'price': t['price'],
                'amount': t['amount'],
                'side': t['side'],
                'timestamp': t['timestamp']
            } for t in trades]
        except Exception as e:
            logger.error(f"خطا در دریافت معاملات {symbol}: {str(e)}")
            return []
    
    def get_exchange_info(self, symbol: str) -> Dict:
        """
        دریافت اطلاعات صرافی درباره یک جفت‌ارز
        
        Args:
            symbol: نماد ارز
            
        Returns:
            دیکشنری اطلاعات
        """
        try:
            info = self.exchange.fetch_markets()
            for market in info:
                if market['symbol'] == symbol:
                    return {
                        'symbol': market['symbol'],
                        'base': market['base'],
                        'quote': market['quote'],
                        'precision': market['precision'],
                        'min_amount': market['limits']['amount']['min'],
                        'max_amount': market['limits']['amount']['max'],
                        'min_price': market['limits']['price']['min'],
                        'max_price': market['limits']['price']['max'],
                        'taker_fee': market['taker'],
                        'maker_fee': market['maker']
                    }
            return {}
        except Exception as e:
            logger.error(f"خطا در دریافت اطلاعات صرافی: {str(e)}")
            return {}


class FearGreedDataLoader:
    """
    کلاس دریافت شاخص ترس و طمع
    منبع: Alternative.me
    """
    
    BASE_URL = "https://api.alternative.me/fng/"
    
    def __init__(self, config: dict):
        """مقداردهی اولیه"""
        self.enabled = config.get('enabled', True)
        self.thresholds = {
            'extreme_fear': config.get('threshold_extreme_fear', 25),
            'fear': config.get('threshold_fear', 40),
            'greed': config.get('threshold_greed', 60),
            'extreme_greed': config.get('threshold_extreme_greed', 75)
        }
        self.cache = {}
        self.cache_timeout = 3600  # 1 ساعت
    
    def get_fear_greed_index(self) -> Dict:
        """
        دریافت شاخص ترس و طمع فعلی
        
        Returns:
            دیکشنری شامل:
            - value: مقدار شاخص (0-100)
            - classification: دسته‌بندی (Extreme Fear, Fear, Neutral, Greed, Extreme Greed)
            - timestamp: زمان آخرین به‌روزرسانی
        """
        try:
            # بررسی کش
            if 'current' in self.cache:
                cached = self.cache['current']
                if (datetime.now() - cached['fetch_time']).seconds < self.cache_timeout:
                    logger.debug("استفاده از داده کش شده ترس و طمع")
                    return cached['data']
            
            # درخواست از API
            response = requests.get(self.BASE_URL, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            
            if data.get('data') and len(data['data']) > 0:
                today_data = data['data'][0]
                
                value = int(today_data['value'])
                value_classification = today_data['value_classification']
                
                # تعیین دسته‌بندی بر اساس مقدار
                if value <= self.thresholds['extreme_fear']:
                    classification = 'Extreme Fear'
                    emoji = '😨'
                elif value <= self.thresholds['fear']:
                    classification = 'Fear'
                    emoji = '😟'
                elif value <= self.thresholds['greed']:
                    classification = 'Neutral'
                    emoji = '😐'
                elif value <= self.thresholds['extreme_greed']:
                    classification = 'Greed'
                    emoji = '😏'
                else:
                    classification = 'Extreme Greed'
                    emoji = '🤪'
                
                result = {
                    'value': value,
                    'classification': classification,
                    'value_classification': value_classification,
                    'emoji': emoji,
                    'timestamp': today_data['timestamp'],
                    'time_until_update': data.get('time_until_update', '')
                }
                
                # ذخیره در کش
                self.cache['current'] = {
                    'data': result,
                    'fetch_time': datetime.now()
                }
                
                logger.info(f"شاخص ترس و طمع: {value} ({classification})")
                return result
            
            return {
                'value': 50,
                'classification': 'Neutral',
                'emoji': '😐',
                'timestamp': '',
                'time_until_update': ''
            }
            
        except requests.RequestException as e:
            logger.error(f"خطا در دریافت شاخص ترس و طمع: {str(e)}")
            return {
                'value': 50,
                'classification': 'Unknown',
                'emoji': '❓',
                'timestamp': '',
                'error': str(e)
            }
    
    def get_historical_data(self, days: int = 30) -> pd.DataFrame:
        """
        دریافت تاریخچه شاخص
        
        Args:
            days: تعداد روزهای گذشته
            
        Returns:
            DataFrame تاریخچه شاخص
        """
        try:
            response = requests.get(
                f"{self.BASE_URL}?limit={days}",
                timeout=10
            )
            response.raise_for_status()
            
            data = response.json()
            
            if data.get('data'):
                df = pd.DataFrame(data['data'])
                df['timestamp'] = pd.to_datetime(df['timestamp'], unit='s')
                df['value'] = pd.to_numeric(df['value'])
                df.set_index('timestamp', inplace=True)
                
                return df[['value', 'value_classification']]
            
            return pd.DataFrame()
            
        except Exception as e:
            logger.error(f"خطا در دریافت تاریخچه ترس و طمع: {str(e)}")
            return pd.DataFrame()


class NewsDataLoader:
    """
    کلاس دریافت و تحلیل اخبار کریپتو
    منابع: CryptoPanic, CoinDesk, CoinTelegraph
    """
    
    def __init__(self, config: dict):
        """مقداردهی اولیه"""
        self.enabled = config.get('enabled', True)
        self.sources = config.get('sources', ['cryptopanic'])
        self.language = config.get('language', 'fa')
        self.recent_count = config.get('recent_news_count', 10)
        self.sensitivity = config.get('sensitivity', 5)
        
        # API Keys (در صورت نیاز)
        self.api_keys = {}
        
        # کش اخبار
        self.news_cache = []
        self.cache_time = None
        self.cache_timeout = 900  # 15 دقیقه
    
    def set_api_key(self, source: str, api_key: str):
        """تنظیم کلید API برای یک منبع"""
        self.api_keys[source] = api_key
    
    def fetch_cryptopanic_news(self, limit: int = 20) -> List[Dict]:
        """
        دریافت اخبار از CryptoPanic
        
        Args:
            limit: تعداد اخبار
            
        Returns:
            لیست اخبار
        """
        try:
            # نسخه رایگان نیاز به API key ندارد
            url = f"https://cryptopanic.com/api/v1/posts/"
            params = {
                'auth_token': self.api_keys.get('cryptopanic', ''),
                'currencies': 'BTC,ETH,BNB,XRP,ADA,SOL,DOGE,DOT,MATIC,LTC',
                'limit': limit,
                'kind': 'news'
            }
            
            response = requests.get(url, params=params, timeout=10)
            response.raise_for_status()
            
            data = response.json()
            
            if data.get('results'):
                news = []
                for item in data['results']:
                    news.append({
                        'title': item.get('title', ''),
                        'url': item.get('url', ''),
                        'source': item.get('source', {}).get('name', 'Unknown'),
                        'published_at': item.get('published_at', ''),
                        'votes': item.get('votes', {}),
                        'currencies': [c['code'] for c in item.get('currencies', [])],
                        'sentiment': item.get('sentiment', {}),
                        'kind': item.get('kind', 'news')
                    })
                
                return news
            
            return []
            
        except Exception as e:
            logger.error(f"خطا در دریافت اخبار CryptoPanic: {str(e)}")
            return []
    
    def fetch_coindesk_news(self, limit: int = 10) -> List[Dict]:
        """
        دریافت اخبار از CoinDesk (RSS Feed)
        
        Args:
            limit: تعداد اخبار
            
        Returns:
            لیست اخبار
        """
        try:
            url = "https://www.coindesk.com/arc/outboundfeeds/rss/"
            response = requests.get(url, timeout=10)
            response.raise_for_status()
            
            # پارس کردن RSS
            import feedparser
            feed = feedparser.parse(response.content)
            
            news = []
            for item in feed.entries[:limit]:
                news.append({
                    'title': item.get('title', ''),
                    'url': item.get('link', ''),
                    'source': 'CoinDesk',
                    'published_at': item.get('published', ''),
                    'summary': item.get('summary', ''),
                    'currencies': self._extract_currencies(item.get('title', '') + ' ' + item.get('summary', ''))
                })
            
            return news
            
        except Exception as e:
            logger.error(f"خطا در دریافت اخبار CoinDesk: {str(e)}")
            return []
    
    def _extract_currencies(self, text: str) -> List[str]:
        """استخراج نام ارزها از متن"""
        currencies = {
            'BTC': 'BTC', 'Bitcoin': 'BTC',
            'ETH': 'ETH', 'Ethereum': 'ETH',
            'BNB': 'BNB', 'Binance Coin': 'BNB',
            'XRP': 'XRP', 'Ripple': 'XRP',
            'ADA': 'ADA', 'Cardano': 'ADA',
            'SOL': 'SOL', 'Solana': 'SOL',
            'DOGE': 'DOGE', 'Dogecoin': 'DOGE',
            'DOT': 'DOT', 'Polkadot': 'DOT',
            'MATIC': 'MATIC', 'Polygon': 'MATIC',
            'LTC': 'LTC', 'Litecoin': 'LTC'
        }
        
        found = []
        text_upper = text.upper()
        for name, code in currencies.items():
            if name.upper() in text_upper and code not in found:
                found.append(code)
        
        return found
    
    def fetch_all_news(self) -> List[Dict]:
        """
        دریافت اخبار از همه منابع پیکربندی شده
        
        Returns:
            لیست یکپارچه اخبار
        """
        # بررسی کش
        if self.cache_time and (datetime.now() - self.cache_time).seconds < self.cache_timeout:
            return self.news_cache
        
        all_news = []
        
        if 'cryptopanic' in self.sources:
            cryptopanic_news = self.fetch_cryptopanic_news(self.recent_count)
            all_news.extend(cryptopanic_news)
        
        if 'coindesk' in self.sources:
            coindesk_news = self.fetch_coindesk_news(10)
            all_news.extend(coindesk_news)
        
        if 'cointelegraph' in self.sources:
            # CoinTelegraph هم می‌تواند اضافه شود
            pass
        
        # مرتب‌سازی بر اساس زمان
        all_news.sort(key=lambda x: x.get('published_at', ''), reverse=True)
        
        # محدود کردن به تعداد مشخص
        all_news = all_news[:self.recent_count]
        
        # ذخیره در کش
        self.news_cache = all_news
        self.cache_time = datetime.now()
        
        logger.info(f"{len(all_news)} خبر دریافت شد")
        return all_news
    
    def get_news_for_symbol(self, symbol: str) -> List[Dict]:
        """
        دریافت اخبار مربوط به یک ارز خاص
        
        Args:
            symbol: نماد ارز (مثلاً BTC/USDT)
            
        Returns:
            لیست اخبار مرتبط
        """
        base_currency = symbol.split('/')[0]
        all_news = self.fetch_all_news()
        
        relevant_news = []
        for news in all_news:
            currencies = news.get('currencies', [])
            if base_currency in currencies or base_currency in news.get('title', ''):
                relevant_news.append(news)
        
        return relevant_news


class DataLoader:
    """
    کلاس اصلی مدیریت دریافت داده‌ها
    تجمیع‌کننده تمام منابع داده
    """
    
    def __init__(self, config: dict):
        """
        مقداردهی اولیه
        
        Args:
            config: دیکشنری تنظیمات کامل
        """
        self.config = config
        
        # مقداردهی اولیه دریافت‌کننده‌ها
        self.exchange_loader = ExchangeDataLoader(config.get('exchange', {}))
        self.fear_greed_loader = FearGreedDataLoader(config.get('sentiment', {}).get('fear_greed', {}))
        self.news_loader = NewsDataLoader(config.get('sentiment', {}).get('news', {}))
        
        # تنظیمات زمانی
        self.timeframe = config.get('schedule', {}).get('timeframe', '1h')
        self.symbols = config.get('exchange', {}).get('symbols', [])
        
        logger.info("سیستم دریافت داده مقداردهی اولیه شد")
    
    def get_market_data(self, symbol: str, limit: int = 100) -> pd.DataFrame:
        """
        دریافت کامل داده‌های بازار
        
        Args:
            symbol: نماد ارز
            limit: تعداد کندل‌ها
            
        Returns:
            DataFrame داده‌های بازار
        """
        return self.exchange_loader.fetch_ohlcv(symbol, self.timeframe, limit)
    
    def get_fear_greed_data(self) -> Dict:
        """دریافت شاخص ترس و طمع"""
        return self.fear_greed_loader.get_fear_greed_index()
    
    def get_news(self, symbol: str = None) -> List[Dict]:
        """
        دریافت اخبار
        
        Args:
            symbol: فیلتر بر اساس ارز (اختیاری)
            
        Returns:
            لیست اخبار
        """
        if symbol:
            return self.news_loader.get_news_for_symbol(symbol)
        return self.news_loader.fetch_all_news()
    
    def get_all_data(self, symbol: str) -> Dict:
        """
        دریافت تمام داده‌های مورد نیاز برای تحلیل
        
        Args:
            symbol: نماد ارز
            
        Returns:
            دیکشنری کامل داده‌ها
        """
        return {
            'market_data': self.get_market_data(symbol),
            'fear_greed': self.get_fear_greed_data(),
            'news': self.get_news(symbol),
            'current_price': self.exchange_loader.get_current_price(symbol),
            'order_book': self.exchange_loader.get_order_book(symbol)
        }
    
    def get_current_prices(self) -> Dict[str, float]:
        """
        دریافت قیمت‌های فعلی تمام ارزهای پیکربندی شده
        
        Returns:
            دیکشنری نماد: قیمت
        """
        prices = {}
        for symbol in self.symbols:
            price = self.exchange_loader.get_current_price(symbol)
            if price > 0:
                prices[symbol] = price
        return prices
