"""
ماژول تحلیل تکنیکال
شامل: اندیکاتورها، الگوهای کندل استیک، سطوح حمایت و مقاومت
نسخه: 1.0.0
"""

import pandas as pd
import numpy as np
import logging
from typing import Dict, List, Optional, Tuple, Any
from dataclasses import dataclass
from enum import Enum

logger = logging.getLogger(__name__)


class TrendDirection(Enum):
    """جهت روند"""
    BULLISH = "صعودی"
    BEARISH = "نزولی"
    SIDEWAYS = "خنثی"


class SignalType(Enum):
    """نوع سیگنال"""
    BUY = "خرید"
    SELL = "فروش"
    HOLD = "نگهداری"
    STRONG_BUY = "خرید قوی"
    STRONG_SELL = "فروش قوی"


@dataclass
class TechnicalIndicators:
    """ساختار داده اندیکاتورهای تکنیکال"""
    # RSI
    rsi: float
    rsi_signal: str  # overbought, oversold, neutral
    
    # MACD
    macd: float
    macd_signal: float
    macd_histogram: float
    macd_trend: str  # bullish, bearish, neutral
    
    # میانگین‌های متحرک
    ema_9: float
    ema_21: float
    ema_50: float
    ema_200: float
    sma_20: float
    sma_50: float
    
    # Bollinger Bands
    bollinger_upper: float
    bollinger_middle: float
    bollinger_lower: float
    bollinger_position: float  # 0-100% موقعیت در باند
    
    # Stochastic
    stochastic_k: float
    stochastic_d: float
    stochastic_signal: str
    
    # اطلاعات اضافی
    current_price: float
    price_change_24h: float
    volume: float
    volume_ratio: float


@dataclass
class SupportResistance:
    """ساختار داده سطوح حمایت و مقاومت"""
    support_levels: List[float]
    resistance_levels: List[float]
    current_position: str  # در کدام سطح قرار دارد
    nearest_support: float
    nearest_resistance: float
    pivot_point: float


@dataclass
class CandlePattern:
    """ساختار داده الگوهای کندل استیک"""
    pattern_name: str
    is_bullish: bool
    confidence: str  # high, medium, low
    description: str


class TechnicalAnalysis:
    """
    کلاس اصلی تحلیل تکنیکال
    محاسبه اندیکاتورها و شناسایی سیگنال‌های تکنیکال
    """
    
    def __init__(self, config: dict):
        """
        مقداردهی اولیه
        
        Args:
            config: دیکشنری تنظیمات تحلیل تکنیکال
        """
        self.config = config
        self.enabled = config.get('enabled', True)
        
        # تنظیمات اندیکاتورها
        self.indicators_config = config.get('indicators', {})
        
        # تنظیمات RSI
        self.rsi_config = self.indicators_config.get('rsi', {})
        self.rsi_period = self.rsi_config.get('period', 14)
        self.rsi_overbought = self.rsi_config.get('overbought', 70)
        self.rsi_oversold = self.rsi_config.get('oversold', 30)
        
        # تنظیمات MACD
        self.macd_config = self.indicators_config.get('macd', {})
        self.macd_fast = self.macd_config.get('fast_period', 12)
        self.macd_slow = self.macd_config.get('slow_period', 26)
        self.macd_signal = self.macd_config.get('signal_period', 9)
        
        # تنظیمات میانگین‌های متحرک
        self.ma_config = self.indicators_config.get('moving_averages', {})
        self.ema_periods = self.ma_config.get('ema_periods', [9, 21, 50, 200])
        self.sma_periods = self.ma_config.get('sma_periods', [20, 50, 200])
        
        # تنظیمات Bollinger Bands
        self.bb_config = self.indicators_config.get('bollinger_bands', {})
        self.bb_period = self.bb_config.get('period', 20)
        self.bb_std = self.bb_config.get('std_dev', 2)
        
        # تنظیمات Stochastic
        self.stoch_config = self.indicators_config.get('stochastic', {})
        self.stoch_k = self.stoch_config.get('k_period', 14)
        self.stoch_d = self.stoch_config.get('d_period', 3)
        
        # تنظیمات سطوح حمایت/مقاومت
        self.sr_config = config.get('support_resistance', {})
        self.sr_lookback = self.sr_config.get('lookback_candles', 100)
        
        # تنظیمات الگوهای کندل
        self.candle_config = config.get('candlestick_patterns', {})
        self.candle_enabled = self.candle_config.get('enabled', True)
        self.candle_patterns = self.candle_config.get('patterns', [])
        
        logger.info("ماژول تحلیل تکنیکال مقداردهی اولیه شد")
    
    def calculate_all_indicators(self, df: pd.DataFrame) -> TechnicalIndicators:
        """
        محاسبه تمام اندیکاتورها
        
        Args:
            df: DataFrame داده‌های OHLCV
            
        Returns:
            TechnicalIndicators: شیء حاوی تمام اندیکاتورها
        """
        if df.empty or len(df) < 200:
            logger.warning("داده‌های کافی برای محاسبه اندیکاتورها وجود ندارد")
            return self._get_empty_indicators()
        
        # قیمت فعلی و اطلاعات پایه
        current_price = df['close'].iloc[-1]
        prev_close = df['close'].iloc[-2] if len(df) > 1 else current_price
        price_change_24h = ((current_price - prev_close) / prev_close) * 100
        
        # حجم معاملات
        volume = df['volume'].iloc[-1]
        avg_volume = df['volume'].rolling(20).mean().iloc[-1]
        volume_ratio = volume / avg_volume if avg_volume > 0 else 1
        
        # محاسبه RSI
        rsi = self._calculate_rsi(df['close'], self.rsi_period)
        rsi_signal = self._get_rsi_signal(rsi)
        
        # محاسبه MACD
        macd_result = self._calculate_macd(
            df['close'],
            self.macd_fast,
            self.macd_slow,
            self.macd_signal
        )
        macd_trend = self._get_macd_trend(macd_result)
        
        # محاسبه میانگین‌های متحرک
        ema_values = {}
        for period in self.ema_periods:
            ema_values[f'ema_{period}'] = self._calculate_ema(df['close'], period)
        
        sma_values = {}
        for period in self.sma_periods:
            sma_values[f'sma_{period}'] = self._calculate_sma(df['close'], period)
        
        # محاسبه Bollinger Bands
        bb_result = self._calculate_bollinger_bands(
            df['close'],
            self.bb_period,
            self.bb_std
        )
        bb_position = self._get_bb_position(current_price, bb_result)
        
        # محاسبه Stochastic
        stoch_result = self._calculate_stochastic(
            df['high'],
            df['low'],
            df['close'],
            self.stoch_k,
            self.stoch_d
        )
        stoch_signal = self._get_stochastic_signal(stoch_result)
        
        return TechnicalIndicators(
            rsi=rsi,
            rsi_signal=rsi_signal,
            macd=macd_result['macd'],
            macd_signal=macd_result['signal'],
            macd_histogram=macd_result['histogram'],
            macd_trend=macd_trend,
            ema_9=ema_values.get('ema_9', 0),
            ema_21=ema_values.get('ema_21', 0),
            ema_50=ema_values.get('ema_50', 0),
            ema_200=ema_values.get('ema_200', 0),
            sma_20=sma_values.get('sma_20', 0),
            sma_50=sma_values.get('sma_50', 0),
            bollinger_upper=bb_result['upper'],
            bollinger_middle=bb_result['middle'],
            bollinger_lower=bb_result['lower'],
            bollinger_position=bb_position,
            stochastic_k=stoch_result['k'],
            stochastic_d=stoch_result['d'],
            stochastic_signal=stoch_signal,
            current_price=current_price,
            price_change_24h=price_change_24h,
            volume=volume,
            volume_ratio=volume_ratio
        )
    
    def _get_empty_indicators(self) -> TechnicalIndicators:
        """برگرداندن اندیکاتورهای خالی در صورت خطا"""
        return TechnicalIndicators(
            rsi=50,
            rsi_signal='neutral',
            macd=0,
            macd_signal=0,
            macd_histogram=0,
            macd_trend='neutral',
            ema_9=0,
            ema_21=0,
            ema_50=0,
            ema_200=0,
            sma_20=0,
            sma_50=0,
            bollinger_upper=0,
            bollinger_middle=0,
            bollinger_lower=0,
            bollinger_position=50,
            stochastic_k=50,
            stochastic_d=50,
            stochastic_signal='neutral',
            current_price=0,
            price_change_24h=0,
            volume=0,
            volume_ratio=1
        )
    
    def _calculate_rsi(self, prices: pd.Series, period: int) -> float:
        """
        محاسبه RSI (Relative Strength Index)
        
        Args:
            prices: سری قیمت‌ها
            period: دوره محاسبه
            
        Returns:
            مقدار RSI (0-100)
        """
        try:
            # محاسبه تغییرات قیمت
            delta = prices.diff()
            
            # جدا کردن سود و ضرر
            gains = delta.clip(lower=0)
            losses = (-delta).clip(lower=0)
            
            # میانگین متحرک نمایی
            avg_gain = gains.ewm(com=period - 1, min_periods=period).mean()
            avg_loss = losses.ewm(com=period - 1, min_periods=period).mean()
            
            # محاسبه RS و RSI
            rs = avg_gain / avg_loss
            rsi = 100 - (100 / (1 + rs))
            
            return rsi.iloc[-1]
            
        except Exception as e:
            logger.error(f"خطا در محاسبه RSI: {str(e)}")
            return 50.0
    
    def _get_rsi_signal(self, rsi: float) -> str:
        """تعیین سیگنال RSI"""
        if rsi >= self.rsi_overbought:
            return 'overbought'
        elif rsi <= self.rsi_oversold:
            return 'oversold'
        else:
            return 'neutral'
    
    def _calculate_macd(self, prices: pd.Series, fast: int, slow: int, signal: int) -> Dict:
        """
        محاسبه MACD (Moving Average Convergence Divergence)
        
        Args:
            prices: سری قیمت‌ها
            fast: دوره سریع
            slow: دوره آهسته
            signal: دوره خط سیگنال
            
        Returns:
            دیکشنری شامل macd, signal, histogram
        """
        try:
            # محاسبه EMAها
            ema_fast = prices.ewm(span=fast, adjust=False).mean()
            ema_slow = prices.ewm(span=slow, adjust=False).mean()
            
            # خط MACD
            macd_line = ema_fast - ema_slow
            
            # خط سیگنال
            signal_line = macd_line.ewm(span=signal, adjust=False).mean()
            
            # هیستوگرام
            histogram = macd_line - signal_line
            
            return {
                'macd': macd_line.iloc[-1],
                'signal': signal_line.iloc[-1],
                'histogram': histogram.iloc[-1],
                'histogram_prev': histogram.iloc[-2] if len(histogram) > 1 else 0
            }
            
        except Exception as e:
            logger.error(f"خطا در محاسبه MACD: {str(e)}")
            return {'macd': 0, 'signal': 0, 'histogram': 0, 'histogram_prev': 0}
    
    def _get_macd_trend(self, macd_data: Dict) -> str:
        """تعیین روند MACD"""
        histogram = macd_data['histogram']
        histogram_prev = macd_data['histogram_prev']
        
        if histogram > 0 and histogram > histogram_prev:
            return 'bullish_strengthening'
        elif histogram > 0 and histogram < histogram_prev:
            return 'bullish_weakening'
        elif histogram < 0 and histogram < histogram_prev:
            return 'bearish_strengthening'
        elif histogram < 0 and histogram > histogram_prev:
            return 'bearish_weakening'
        else:
            return 'neutral'
    
    def _calculate_ema(self, prices: pd.Series, period: int) -> float:
        """محاسبه EMA (Exponential Moving Average)"""
        try:
            ema = prices.ewm(span=period, adjust=False).mean()
            return ema.iloc[-1]
        except Exception as e:
            logger.error(f"خطا در محاسبه EMA({period}): {str(e)}")
            return 0.0
    
    def _calculate_sma(self, prices: pd.Series, period: int) -> float:
        """محاسبه SMA (Simple Moving Average)"""
        try:
            sma = prices.rolling(window=period).mean()
            return sma.iloc[-1]
        except Exception as e:
            logger.error(f"خطا در محاسبه SMA({period}): {str(e)}")
            return 0.0
    
    def _calculate_bollinger_bands(self, prices: pd.Series, period: int, std_dev: int) -> Dict:
        """
        محاسبه Bollinger Bands
        
        Args:
            prices: سری قیمت‌ها
            period: دوره محاسبه
            std_dev: انحراف معیار
            
        Returns:
            دیکشنری upper, middle, lower
        """
        try:
            middle = prices.rolling(window=period).mean()
            std = prices.rolling(window=period).std()
            
            upper = middle + (std * std_dev)
            lower = middle - (std * std_dev)
            
            return {
                'upper': upper.iloc[-1],
                'middle': middle.iloc[-1],
                'lower': lower.iloc[-1]
            }
        except Exception as e:
            logger.error(f"خطا در محاسبه Bollinger Bands: {str(e)}")
            return {'upper': 0, 'middle': 0, 'lower': 0}
    
    def _get_bb_position(self, price: float, bb_data: Dict) -> float:
        """محاسبه موقعیت قیمت در Bollinger Bands (0-100%)"""
        try:
            upper = bb_data['upper']
            lower = bb_data['lower']
            middle = bb_data['middle']
            
            if upper == lower:
                return 50
            
            position = ((price - lower) / (upper - lower)) * 100
            return max(0, min(100, position))
            
        except Exception as e:
            logger.error(f"خطا در محاسبه موقعیت BB: {str(e)}")
            return 50.0
    
    def _calculate_stochastic(self, high: pd.Series, low: pd.Series, 
                              close: pd.Series, k_period: int, d_period: int) -> Dict:
        """
        محاسبه Stochastic Oscillator
        
        Args:
            high: سری قیمت بالا
            low: سری قیمت پایین
            close: سری قیمت بسته شدن
            k_period: دوره K
            d_period: دوره D
            
        Returns:
            دیکشنری k و d
        """
        try:
            lowest_low = low.rolling(window=k_period).min()
            highest_high = high.rolling(window=k_period).max()
            
            k = 100 * ((close - lowest_low) / (highest_high - lowest_low))
            d = k.rolling(window=d_period).mean()
            
            return {
                'k': k.iloc[-1],
                'd': d.iloc[-1]
            }
        except Exception as e:
            logger.error(f"خطا در محاسبه Stochastic: {str(e)}")
            return {'k': 50, 'd': 50}
    
    def _get_stochastic_signal(self, stoch_data: Dict) -> str:
        """تعیین سیگنال Stochastic"""
        k = stoch_data['k']
        d = stoch_data['d']
        
        if k >= 80 and d >= 80:
            return 'overbought'
        elif k <= 20 and d <= 20:
            return 'oversold'
        elif k > d:
            return 'bullish'
        elif k < d:
            return 'bearish'
        else:
            return 'neutral'
    
    def find_support_resistance(self, df: pd.DataFrame) -> SupportResistance:
        """
        شناسایی سطوح حمایت و مقاومت
        
        Args:
            df: DataFrame داده‌های قیمت
            
        Returns:
            SupportResistance: شیء سطوح حمایت و مقاومت
        """
        try:
            if df.empty or len(df) < self.sr_lookback:
                return SupportResistance(
                    support_levels=[],
                    resistance_levels=[],
                    current_position='unknown',
                    nearest_support=0,
                    nearest_resistance=0,
                    pivot_point=0
                )
            
            # استفاده از داده‌های محدود شده
            lookback_df = df.tail(self.sr_lookback)
            
            # یافتن سقف‌ها (مقاومت)
            high_periods = 5
            resistance_levels = []
            for i in range(high_periods, len(lookback_df) - high_periods):
                is_resistance = True
                for j in range(1, high_periods + 1):
                    if lookback_df['high'].iloc[i] <= lookback_df['high'].iloc[i - j] or \
                       lookback_df['high'].iloc[i] <= lookback_df['high'].iloc[i + j]:
                        is_resistance = False
                        break
                if is_resistance:
                    level = lookback_df['high'].iloc[i]
                    if not any(abs(level - r) / level < 0.01 for r in resistance_levels):
                        resistance_levels.append(level)
            
            # یافتن کف‌ها (حمایت)
            support_levels = []
            for i in range(high_periods, len(lookback_df) - high_periods):
                is_support = True
                for j in range(1, high_periods + 1):
                    if lookback_df['low'].iloc[i] >= lookback_df['low'].iloc[i - j] or \
                       lookback_df['low'].iloc[i] >= lookback_df['low'].iloc[i + j]:
                        is_support = False
                        break
                if is_support:
                    level = lookback_df['low'].iloc[i]
                    if not any(abs(level - s) / level < 0.01 for s in support_levels):
                        support_levels.append(level)
            
            # محاسبه Pivot Point
            last_high = df['high'].iloc[-1]
            last_low = df['low'].iloc[-1]
            last_close = df['close'].iloc[-1]
            pivot = (last_high + last_low + last_close) / 3
            
            # مرتب‌سازی سطوح
            support_levels.sort(reverse=True)
            resistance_levels.sort()
            
            # یافتن نزدیک‌ترین سطوح
            current_price = df['close'].iloc[-1]
            nearest_support = max([s for s in support_levels if s < current_price], 
                                  default=current_price * 0.95)
            nearest_resistance = min([r for r in resistance_levels if r > current_price],
                                     default=current_price * 1.05)
            
            # تعیین موقعیت فعلی
            if current_price > resistance_levels[0] if resistance_levels else False:
                current_position = 'above_resistance'
            elif current_price < support_levels[-1] if support_levels else False:
                current_position = 'below_support'
            elif current_price > pivot:
                current_position = 'bullish_zone'
            elif current_price < pivot:
                current_position = 'bearish_zone'
            else:
                current_position = 'pivot_zone'
            
            return SupportResistance(
                support_levels=support_levels[:5],  # 5 سطح اول
                resistance_levels=resistance_levels[:5],
                current_position=current_position,
                nearest_support=nearest_support,
                nearest_resistance=nearest_resistance,
                pivot_point=pivot
            )
            
        except Exception as e:
            logger.error(f"خطا در شناسایی سطوح حمایت/مقاومت: {str(e)}")
            return SupportResistance(
                support_levels=[],
                resistance_levels=[],
                current_position='unknown',
                nearest_support=0,
                nearest_resistance=0,
                pivot_point=0
            )
    
    def analyze_candlesticks(self, df: pd.DataFrame) -> List[CandlePattern]:
        """
        شناسایی الگوهای کندل استیک
        
        Args:
            df: DataFrame داده‌های قیمت
            
        Returns:
            لیست الگوهای شناسایی شده
        """
        patterns = []
        
        if df.empty or len(df) < 3:
            return patterns
        
        try:
            # کندل آخر
            last = df.iloc[-1]
            prev = df.iloc[-2] if len(df) > 1 else None
            prev2 = df.iloc[-3] if len(df) > 2 else None
            
            if prev is None:
                return patterns
            
            body_last = abs(last['close'] - last['open'])
            body_prev = abs(prev['close'] - prev['open'])
            upper_shadow_last = last['high'] - max(last['open'], last['close'])
            lower_shadow_last = min(last['open'], last['close']) - last['low']
            upper_shadow_prev = prev['high'] - max(prev['open'], prev['close'])
            lower_shadow_prev = min(prev['open'], prev['close']) - prev['low']
            
            # بررسی Doji
            if body_last <= (last['high'] - last['low']) * 0.1:
                patterns.append(CandlePattern(
                    pattern_name='Doji',
                    is_bullish=last['close'] > last['open'],
                    confidence='medium',
                    description='عدم قطعیت در بازار'
                ))
            
            # بررسی Hammer (چکش)
            if 'hammer' in self.candle_patterns:
                total_range = last['high'] - last['low']
                if total_range > 0:
                    lower_shadow = min(last['open'], last['close']) - last['low']
                    upper_shadow = last['high'] - max(last['open'], last['close'])
                    body = abs(last['close'] - last['open'])
                    
                    if lower_shadow >= 2 * body and upper_shadow <= body * 0.3:
                        patterns.append(CandlePattern(
                            pattern_name='Hammer',
                            is_bullish=True,
                            confidence='high' if last['close'] > last['open'] else 'medium',
                            description='الگوی چکش - احتمال بازگشت صعودی'
                        ))
            
            # بررسی Engulfing (پوشا)
            if prev2 is not None and 'engulfing' in self.candle_patterns:
                body_prev = abs(prev['close'] - prev['open'])
                body_curr = abs(last['close'] - last['open'])
                
                # صعودی
                if (prev['close'] < prev['open'] and  # کندل قبلی نزولی
                    last['close'] > last['open'] and  # کندل فعلی صعودی
                    last['open'] < prev['close'] and  # باز شدن کمتر از بسته شدن قبلی
                    last['close'] > prev['open']):    # بسته شدن بیشتر از باز شدن قبلی
                    
                    if body_curr > body_prev:
                        patterns.append(CandlePattern(
                            pattern_name='Bullish Engulfing',
                            is_bullish=True,
                            confidence='high',
                            description='الگوی پوشا صعودی - تغییر روند'
                        ))
                
                # نزولی
                if (prev['close'] > prev['open'] and  # کندل قبلی صعودی
                    last['close'] < last['open'] and  # کندل فعلی نزولی
                    last['open'] > prev['close'] and  # باز شدن بیشتر از بسته شدن قبلی
                    last['close'] < prev['open']):    # بسته شدن کمتر از باز شدن قبلی
                    
                    if body_curr > body_prev:
                        patterns.append(CandlePattern(
                            pattern_name='Bearish Engulfing',
                            is_bullish=False,
                            confidence='high',
                            description='الگوی پوشا نزولی - تغییر روند'
                        ))
            
            # بررسی Morning/Evening Star
            if prev2 is not None and ('morning_star' in self.candle_patterns or 
                                       'evening_star' in self.candle_patterns):
                
                body_prev2 = abs(prev2['close'] - prev2['open'])
                body_prev = abs(prev['close'] - prev['open'])
                body_curr = abs(last['close'] - last['open'])
                
                # Morning Star (ستاره صبحگاهی)
                if (prev2['close'] < prev2['open'] and  # کندل اول نزولی
                    prev['close'] > prev['open'] and  # کندل دوم صعودی کوچک
                    last['close'] > last['open'] and  # کندل سوم صعودی
                    body_curr > body_prev2 * 0.6 and  # کندل سوم بزرگ
                    prev['close'] < prev2['close'] and prev['close'] > prev2['open']):  # شکاف
                    
                    patterns.append(CandlePattern(
                        pattern_name='Morning Star',
                        is_bullish=True,
                        confidence='high',
                        description='الگوی ستاره صبحگاهی - سیگنال خرید قوی'
                    ))
                
                # Evening Star (ستاره شامگاهی)
                if (prev2['close'] > prev2['open'] and  # کندل اول صعودی
                    prev['close'] > prev['open'] and  # کندل دوم نزولی کوچک
                    last['close'] < last['open'] and  # کندل سوم نزولی
                    body_curr > body_prev2 * 0.6 and  # کندل سوم بزرگ
                    prev['close'] > prev2['close'] and prev['close'] < prev2['open']):  # شکاف
                    
                    patterns.append(CandlePattern(
                        pattern_name='Evening Star',
                        is_bullish=False,
                        confidence='high',
                        description='الگوی ستاره شامگاهی - سیگنال فروش قوی'
                    ))
            
        except Exception as e:
            logger.error(f"خطا در تحلیل کندل‌ها: {str(e)}")
        
        return patterns
    
    def determine_trend(self, df: pd.DataFrame, indicators: TechnicalIndicators) -> Tuple[TrendDirection, float]:
        """
        تعیین روند کلی بازار
        
        Args:
            df: DataFrame داده‌های قیمت
            indicators: اندیکاتورهای محاسبه شده
            
        Returns:
            Tuple(TrendDirection, strength): جهت روند و قدرت آن (0-100)
        """
        try:
            trend_score = 0
            current_price = indicators.current_price
            ema_50 = indicators.ema_50
            ema_200 = indicators.ema_200
            
            # بررسی موقعیت قیمت نسبت به میانگین‌ها
            if current_price > ema_50:
                trend_score += 15
            else:
                trend_score -= 15
            
            if current_price > ema_200:
                trend_score += 20
            else:
                trend_score -= 20
            
            # Golden Cross / Death Cross
            if ema_50 > ema_200:
                trend_score += 25  # صعودی
            else:
                trend_score -= 25  # نزولی
            
            # بررسی RSI
            rsi = indicators.rsi
            if 45 <= rsi <= 55:
                trend_score += 5  # خنثی
            elif rsi > 55:
                trend_score += min(10, (rsi - 55) * 0.5)
            else:
                trend_score -= min(10, (55 - rsi) * 0.5)
            
            # بررسی MACD
            macd_trend = indicators.macd_trend
            if 'bullish' in macd_trend:
                trend_score += 15
            elif 'bearish' in macd_trend:
                trend_score -= 15
            
            # بررسی روند قیمت از روی داده‌ها
            if len(df) >= 20:
                ma_20 = df['close'].rolling(20).mean().iloc[-1]
                ma_50_df = df['close'].rolling(50).mean().iloc[-1]
                
                if df['close'].iloc[-1] > ma_20:
                    trend_score += 10
                if ma_20 > ma_50_df:
                    trend_score += 10
            
            # محدود کردن امتیاز
            trend_score = max(-100, min(100, trend_score))
            
            # تعیین جهت روند
            if trend_score >= 30:
                direction = TrendDirection.BULLISH
            elif trend_score <= -30:
                direction = TrendDirection.BEARISH
            else:
                direction = TrendDirection.SIDEWAYS
            
            return direction, abs(trend_score)
            
        except Exception as e:
            logger.error(f"خطا در تعیین روند: {str(e)}")
            return TrendDirection.SIDEWAYS, 0
    
    def get_technical_summary(self, df: pd.DataFrame) -> Dict:
        """
        دریافت خلاصه تحلیل تکنیکال
        
        Args:
            df: DataFrame داده‌های قیمت
            
        Returns:
            دیکشنری کامل تحلیل تکنیکال
        """
        if df.empty or len(df) < 200:
            return {'error': 'داده‌های کافی وجود ندارد'}
        
        # محاسبه اندیکاتورها
        indicators = self.calculate_all_indicators(df)
        
        # یافتن سطوح حمایت/مقاومت
        sr_levels = self.find_support_resistance(df)
        
        # شناسایی الگوهای کندل
        candle_patterns = self.analyze_candlesticks(df)
        
        # تعیین روند
        trend, trend_strength = self.determine_trend(df, indicators)
        
        # ارزیابی کلی
        overall_score = self._calculate_overall_score(indicators, sr_levels, candle_patterns, trend)
        
        return {
            'indicators': indicators,
            'support_resistance': sr_levels,
            'candle_patterns': candle_patterns,
            'trend': {
                'direction': trend.value,
                'strength': trend_strength
            },
            'overall_score': overall_score,
            'recommendation': self._get_recommendation(overall_score, indicators, trend)
        }
    
    def _calculate_overall_score(self, indicators: TechnicalIndicators,
                                 sr_levels: SupportResistance,
                                 candle_patterns: List[CandlePattern],
                                 trend: TrendDirection) -> int:
        """محاسبه امتیاز کلی تحلیل تکنیکال"""
        score = 50  # امتیاز پایه
        
        # RSI (15 امتیاز)
        if indicators.rsi_signal == 'oversold':
            score += 15  # فرصت خرید
        elif indicators.rsi_signal == 'overbought':
            score -= 15  # ریسک فروش
        elif indicators.rsi < 45:
            score += 5
        elif indicators.rsi > 55:
            score -= 5
        
        # MACD (15 امتیاز)
        if 'bullish' in indicators.macd_trend:
            score += 15
        elif 'bearish' in indicators.macd_trend:
            score -= 15
        
        # میانگین‌های متحرک (20 امتیاز)
        if indicators.current_price > indicators.ema_50:
            score += 10
        if indicators.current_price > indicators.ema_200:
            score += 10
        if indicators.ema_50 > indicators.ema_200:
            score += 10
        elif indicators.ema_50 < indicators.ema_200:
            score -= 10
        
        # Bollinger Bands (10 امتیاز)
        bb_pos = indicators.bollinger_position
        if bb_pos < 20:
            score += 10  # نزدیک کف باند - فرصت خرید
        elif bb_pos > 80:
            score -= 10  # نزدیک سقف باند - ریسک
        
        # Stochastic (10 امتیاز)
        if indicators.stochastic_signal == 'oversold':
            score += 10
        elif indicators.stochastic_signal == 'overbought':
            score -= 10
        
        # روند (15 امتیاز)
        if trend == TrendDirection.BULLISH:
            score += 15
        elif trend == TrendDirection.BEARISH:
            score -= 15
        
        # الگوهای کندل (15 امتیاز)
        bullish_count = sum(1 for p in candle_patterns if p.is_bullish)
        bearish_count = sum(1 for p in candle_patterns if not p.is_bullish)
        score += bullish_count * 5
        score -= bearish_count * 5
        
        return max(0, min(100, score))
    
    def _get_recommendation(self, score: int, indicators: TechnicalIndicators,
                           trend: TrendDirection) -> SignalType:
        """تعیین توصیه نهایی"""
        if score >= 80:
            return SignalType.STRONG_BUY
        elif score >= 60:
            return SignalType.BUY
        elif score >= 40:
            return SignalType.HOLD
        elif score >= 20:
            return SignalType.SELL
        else:
            return SignalType.STRONG_SELL
