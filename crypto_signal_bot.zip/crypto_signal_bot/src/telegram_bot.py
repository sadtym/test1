"""
ماژول ارسال پیام به تلگرام
نسخه: 1.0.0
"""

import logging
from typing import Dict, List, Optional, Any
from datetime import datetime
import requests
import json

logger = logging.getLogger(__name__)


class TelegramBot:
    """
    کلاس مدیریت ارسال پیام به تلگرام
    """
    
    def __init__(self, config: dict):
        """
        مقداردهی اولیه
        
        Args:
            config: دیکشنری تنظیمات تلگرام
        """
        self.config = config
        self.enabled = config.get('enabled', True)
        self.bot_token = config.get('bot_token', '')
        self.chat_id = config.get('chat_id', '')
        
        # تنظیمات API تلگرام
        self.base_url = f"https://api.telegram.org/bot{self.bot_token}"
        
        # وضعیت اتصال
        self.connected = False
        
        # آمار ارسال
        self.messages_sent = 0
        self.messages_failed = 0
        
        logger.info("ماژول تلگرام مقداردهی اولیه شد")
    
    def test_connection(self) -> bool:
        """
        تست اتصال به تلگرام
        
        Returns:
            True اگر اتصال موفق باشد
        """
        try:
            url = f"{self.base_url}/getMe"
            response = requests.get(url, timeout=10)
            data = response.json()
            
            if data.get('ok'):
                bot_info = data.get('result', {})
                logger.info(f"اتصال به تلگرام موفق: @{bot_info.get('username', 'Unknown')}")
                self.connected = True
                return True
            else:
                logger.error(f"خطا در اتصال به تلگرام: {data.get('description')}")
                self.connected = False
                return False
                
        except Exception as e:
            logger.error(f"خطا در تست اتصال تلگرام: {str(e)}")
            self.connected = False
            return False
    
    def send_message(self, 
                    text: str, 
                    parse_mode: str = 'HTML',
                    disable_web_page_preview: bool = True,
                    disable_notification: bool = False) -> bool:
        """
        ارسال پیام متنی به تلگرام
        
        Args:
            text: متن پیام
            parse_mode: فرمت‌بندی (HTML, Markdown, MarkdownV2)
            disable_web_page_preview: غیرفعال کردن پیش‌نمایش لینک
            disable_notification: ارسال بدون اعلان
            
        Returns:
            True اگر ارسال موفق باشد
        """
        if not self.enabled:
            logger.debug("ارسال پیام تلگرام غیرفعال است")
            return False
        
        if not self.bot_token or not self.chat_id:
            logger.error("توکن ربات یا chat_id تنظیم نشده است")
            return False
        
        try:
            url = f"{self.base_url}/sendMessage"
            payload = {
                'chat_id': self.chat_id,
                'text': text,
                'parse_mode': parse_mode,
                'disable_web_page_preview': disable_web_page_preview,
                'disable_notification': disable_notification
            }
            
            response = requests.post(url, json=payload, timeout=10)
            data = response.json()
            
            if data.get('ok'):
                self.messages_sent += 1
                logger.debug(f"پیام تلگرام ارسال شد")
                return True
            else:
                self.messages_failed += 1
                logger.error(f"خطا در ارسال پیام تلگرام: {data.get('description')}")
                return False
                
        except requests.RequestException as e:
            self.messages_failed += 1
            logger.error(f"خطای شبکه در ارسال پیام تلگرام: {str(e)}")
            return False
        except Exception as e:
            self.messages_failed += 1
            logger.error(f"خطای ناشناخته در ارسال پیام تلگرام: {str(e)}")
            return False
    
    def send_signal(self, signal) -> bool:
        """
        ارسال سیگنال به تلگرام
        
        Args:
            signal: شیء سیگنال
            
        Returns:
            True اگر ارسال موفق باشد
        """
        if not signal or not signal.should_send:
            return False
        
        message = signal.telegram_message
        if not message:
            logger.warning("پیام سیگنال خالی است")
            return False
        
        return self.send_message(message)
    
    def send_price_alert(self,
                        symbol: str,
                        price: float,
                        change_percent: float,
                        alert_type: str = 'info') -> bool:
        """
        ارسال هشدار تغییر قیمت
        
        Args:
            symbol: نماد ارز
            price: قیمت فعلی
            change_percent: درصد تغییر
            alert_type: نوع هشدار (info, warning, critical)
            
        Returns:
            True اگر ارسال موفق باشد
        """
        # تعیین ایموجی بر اساس تغییر قیمت
        if change_percent > 5:
            emoji = "🚀"
            alert_type = "green"
        elif change_percent > 2:
            emoji = "📈"
            alert_type = "green"
        elif change_percent > 0:
            emoji = "↗️"
            alert_type = "green"
        elif change_percent > -2:
            emoji = "↘️"
            alert_type = "red"
        elif change_percent > -5:
            emoji = "📉"
            alert_type = "red"
        else:
            emoji = "💥"
            alert_type = "red"
        
        # قالب‌بندی قیمت
        if price >= 100:
            price_format = f"${price:,.2f}"
        elif price >= 1:
            price_format = f"${price:,.4f}"
        else:
            price_format = f"${price:,.6f}"
        
        # ساخت پیام
        change_emoji = "🟢" if change_percent >= 0 else "🔴"
        message = f"""
{emoji} <b>هشدار قیمت</b> - {symbol}

💰 <b>قیمت فعلی:</b> {price_format}
{change_emoji} <b>تغییر 24h:</b> {change_percent:+.2f}%

⏰ زمان: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""
        
        return self.send_message(message)
    
    def send_daily_report(self, 
                         summary: Dict,
                         top_movers: List[Dict],
                         market_sentiment: Dict) -> bool:
        """
        ارسال گزارش روزانه
        
        Args:
            summary: خلاصه آمار
            top_movers: لیست ارزهای پرنوسان
            market_sentiment: احساسات بازار
            
        Returns:
            True اگر ارسال موفق باشد
        """
        # ساخت پیام
        message = f"""
📊 <b>گزارش روزانه بازار ارزهای دیجیتال</b>
📅 تاریخ: {datetime.now().strftime('%Y-%m-%d')}

{'='*40}

🧠 <b>احساسات بازار:</b>
• شاخص ترس و طمع: {market_sentiment.get('value', 'N/A')} {market_sentiment.get('emoji', '')}
• وضعیت: {market_sentiment.get('classification', 'N/A')}
• خلاصه: {market_sentiment.get('summary', 'N/A')}

{'='*40}

📈 <b>خلاصه سیگنال‌ها:</b>
• کل سیگنال‌ها: {summary.get('total_signals', 0)}
• سیگنال خرید: {summary.get('buy_signals', 0)}
• سیگنال فروش: {summary.get('sell_signals', 0)}
• میانگین امتیاز: {summary.get('avg_score', 0):.1f}

{'='*40}

🔥 <b>ارزهای پرنوسان:</b>
"""
        
        # اضافه کردن ارزهای پرنوسان
        for i, mover in enumerate(top_movers[:5], 1):
            symbol = mover.get('symbol', 'N/A')
            change = mover.get('change_percent', 0)
            price = mover.get('price', 0)
            
            if change >= 0:
                emoji = "🟢"
                change_str = f"+{change:.2f}%"
            else:
                emoji = "🔴"
                change_str = f"{change:.2f}%"
            
            # قالب‌بندی قیمت
            if price >= 100:
                price_str = f"${price:,.2f}"
            elif price >= 1:
                price_str = f"${price:,.4f}"
            else:
                price_str = f"${price:,.6f}"
            
            message += f"\n{i}. {emoji} <b>{symbol}</b> {price_str} ({change_str})"
        
        message += f"""

{'='*40}

⏰ زمان گزارش: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}

<i>⚠️ این گزارش صرفاً جنبه اطلاع‌رسانی دارد.</i>
"""
        
        return self.send_message(message)
    
    def send_error_alert(self, error_message: str, error_type: str = 'Error') -> bool:
        """
        ارسال هشدار خطا
        
        Args:
            error_message: متن خطا
            error_type: نوع خطا
            
        Returns:
            True اگر ارسال موفق باشد
        """
        message = f"""
⚠️ <b>هشدار خطا</b>

🔴 <b>نوع خطا:</b> {error_type}
📝 <b>پیام:</b> {error_message}
⏰ <b>زمان:</b> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""
        
        return self.send_message(message)
    
    def send_startup_notification(self, config_summary: Dict) -> bool:
        """
        ارسال پیام راه‌اندازی
        
        Args:
            config_summary: خلاصه تنظیمات
            
        Returns:
            True اگر ارسال موفق باشد
        """
        symbols = config_summary.get('symbols', [])
        timeframe = config_summary.get('timeframe', '1h')
        
        message = f"""
✅ <b>بات تحلیل ارز دیجیتال راه‌اندازی شد</b>

🔧 <b>تنظیمات:</b>
• جفت‌ارزها: {', '.join(symbols[:5])}{'...' if len(symbols) > 5 else ''}
• تایم‌فریم: {timeframe}
• وضعیت: فعال

📊 <b>زمان شروع:</b> {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}
"""
        
        return self.send_message(message)
    
    def get_chat_info(self) -> Dict:
        """
        دریافت اطلاعات کانال/گروه
        
        Returns:
            دیکشنری اطلاعات
        """
        try:
            url = f"{self.base_url}/getChat"
            payload = {'chat_id': self.chat_id}
            
            response = requests.post(url, json=payload, timeout=10)
            data = response.json()
            
            if data.get('ok'):
                return data.get('result', {})
            else:
                logger.error(f"خطا در دریافت اطلاعات کانال: {data.get('description')}")
                return {}
                
        except Exception as e:
            logger.error(f"خطا در دریافت اطلاعات کانال: {str(e)}")
            return {}
    
    def get_stats(self) -> Dict:
        """
        دریافت آمار
        
        Returns:
            دیکشنری آمار
        """
        return {
            'connected': self.connected,
            'messages_sent': self.messages_sent,
            'messages_failed': self.messages_failed,
            'success_rate': (
                self.messages_sent / max(1, self.messages_sent + self.messages_failed)
            ) * 100
        }
